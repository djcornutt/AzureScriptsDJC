

$vms = (Get-AzVM).Name

foreach ($VM in $vms)

{

$agent = $vm | Select -ExpandProperty OSProfile | select -ExpandProperty WindowsConfiguration | select ProvisionVMAgent
Write-Host $vm.name $agent.ProvisionVMAgent 


}



###Script written by Sunny Punn###
###     Date June 16, 2019     ###
###Edits by Drew Cornutt 9-Mar-2021###
<# commented out Availability set creation 
Substituted all AzureRM module commands for Az Module commands
corrected $VirtualMachine vs $VirtualMachineName problem in lower config and New commands
 #>

#Variables to modify
$VMName = "A1IPRPAMPAM010"
#$sourceSubscriptionId = (Set-AzContext -SubscriptionName 'Mgmt-Ops')
$SourceResourceGroupName = "AZ-GOV-MGMT-OPS-CAPAM-VA"
#$targetsubscriptionId = (Set-AzContext -SubscriptionName 'Mgmt-Ops')
$targetResourceGroupName = "AZ-GOV-MGMT-OPS-PAM-VA"
$TargetVNETresourceGroupName = 'AZ-GOV-MGMT-TOOLS-VA'
$TargetvirtualNetworkName = 'AZ-GOV-MGMT-TOOLS-VA'
$subnetNumber = '1'
$TargetvirtualMachineSize = 'Standard_D16ds_v4'
#$TargetAvailabilitySetName = 'testavs1'
$targetlocation = 'usgovvirginia'
$targetstorageType = 'Premium_LRS'

$sub = (Set-AzContext -SubscriptionName 'Mgmt-Ops')

$date = Get-Date -format "yyyyMMddhhmm"

Set-AzContext -SubscriptionName 'Mgmt-Ops'
#Select-AzSubscription -SubscriptionId $sourceSubscriptionId

$vms = Get-AzVm -ResourceGroupName $SourceResourceGroupName | Where-Object {($_.name -like $VMName)} #-bor ($_.name -like "A1IFQDEVSVP001")-bor ($_.name -like "A1IFQDEVSVP002") }
write-host "VMs that have been selected is/are: " $vms.name  -ForegroundColor "Green"

write-host -nonewline "Continue? (Y/N) "
$response = read-host
if ( $response -ne "Y" ) { break }



    foreach ($vm in $vms) {

        #Select-AzSubscription -SubscriptionId $sourceSubscriptionId

        $OSdisk = Get-AzDisk -ResourceGroupName $SourceResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
        $snapConfig = New-AzSnapshotConfig -SourceUri $OSdisk.Id -CreateOption Copy -Location $vm.Location
        $OSsnapshot = New-AzSnapshot -ResourceGroupName $SourceResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig
        Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"

        Select-AzSubscription -SubscriptionId $targetSubscriptionId
        $OSsnapshotConfig = New-AzSnapshotConfig -SourceResourceId $OSsnapshot.Id -Location $OSsnapshot.Location -CreateOption Copy -SkuName $targetstorageType
        New-AzSnapshot -Snapshot $OSsnapshotConfig -SnapshotName $OSsnapshot.Name -ResourceGroupName $targetResourceGroupName 
        Write-Host "Snapshot copied to target subscription " $OSsnapshotConfig -ForegroundColor "Green"

        $snapshotName = $OSsnapshot.Name
        $osDiskName = ($vm.Name + '_OS_' + 'Disk')
        $virtualMachineName = ($vm.Name)
        #$availabilitySet = Get-AzAvailabilitySet -ResourceGroupName $targetResourceGroupName -AvailabilitySetName $TargetAvailabilitySetName

        #Select-AzSubscription -SubscriptionId $targetSubscriptionId

        $snapshot = Get-AzSnapshot -ResourceGroupName $targetResourceGroupName -SnapshotName $snapshotName    
        $diskConfig = New-AzDiskConfig -Location $snapshot.Location -SourceResourceId $snapshot.Id -CreateOption Copy -SkuName $targetstorageType
        $disk = New-AzDisk -Disk $diskConfig -ResourceGroupName $targetResourceGroupName -DiskName $osDiskName
        $VirtualMachine = New-AzVMConfig -VMName $virtualMachineName -VMSize $TargetvirtualMachineSize #-AvailabilitySetId $AvailabilitySet.Id#
        $VirtualMachine = Set-AzVMOSDisk -VM $virtualMachineName -ManagedDiskId $disk.Id -CreateOption Attach -Windows
        $vnet = Get-AzVirtualNetwork -Name $TargetvirtualNetworkName -ResourceGroupName $TargetVNETresourceGroupName
        $nic = New-AzNetworkInterface -Name ($VirtualMachineName.ToLower()+'_nic') -ResourceGroupName $targetResourceGroupName -Location $snapshot.Location -SubnetId $vnet.Subnets[$subnetNumber].Id 
        $VirtualMachine = Add-AzVMNetworkInterface -VM $VirtualMachineName -Id $nic.Id


            $i = 0
            foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
                #Select-AzSubscription -SubscriptionId $sourceSubscriptionId
                $i++
                $Datadisk = Get-AzDisk -ResourceGroupName $SourceResourceGroupName -DiskName $dataDisk.Name
                $snapConfig = New-AzSnapshotConfig -SourceUri $Datadisk.Id -CreateOption Copy -Location $vm.Location
                $Datasnapshot = New-AzSnapshot -ResourceGroupName $SourceResourceGroupName -SnapshotName $($vm.Name + '_data_' + $i + $date) -Snapshot $snapConfig
                Write-Host "Snapshot created on DATA disk with file name labeled as: " $($vm.Name + '_DATA_'+$i +'_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
        
                #Select-AzSubscription -SubscriptionId $targetSubscriptionId
                $DatasnapshotConfig = New-AzSnapshotConfig -SourceResourceId $Datasnapshot.Id -Location $Datasnapshot.Location -CreateOption Copy -SkuName $targetstorageType
                $targetSnapshot = New-AzSnapshot -Snapshot $DatasnapshotConfig -SnapshotName $Datasnapshot.Name -ResourceGroupName $targetResourceGroupName 

                $targetdiskName = $($vm.Name + '_DATA_' + $i)
                $targetdisksize = $datadisk.DiskSizeGB

                $diskConfig = New-AzDiskConfig -AccountType $targetstorageType -Location $targetlocation -CreateOption Copy -SourceResourceId $targetSnapshot.Id
                write-output $diskConfig

                $targetdatadisk = New-AzDisk -Disk $diskConfig -ResourceGroupName $targetResourceGroupName -DiskName $targetdiskName
                Write-Output $targetdatadisk

                $disk = Get-AzDisk -ResourceGroupName $targetResourceGroupName -DiskName $targetdatadisk.Name

                $VirtualMachine = Add-AzVMDataDisk -CreateOption Attach -Lun $i -VM $VirtualMachine -ManagedDiskId $disk.Id
            }

        #Select-AzSubscription -SubscriptionId $sourceSubscriptionId
        Remove-AzVM -Name $virtualMachineName -ResourceGroupName $SourceResourceGroupName -Force
        write-host "Deleting source VM leaving behind the snapshot, os disks, data disks, NICs and NSGs" -ForegroundColor "cyan"

        #Select-AzSubscription -SubscriptionId $targetSubscriptionId
        write-host "creating VM step in Target ResourceGroup " + $sub.Name -ForegroundColor "cyan"
        $newVMcreated = New-AzVM -VM $virtualMachine -ResourceGroupName $targetResourceGroupName -Location $snapshot.Location 

    }

Write-Host "Move is complete"
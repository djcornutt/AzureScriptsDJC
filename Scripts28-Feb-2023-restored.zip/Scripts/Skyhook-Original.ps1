# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"


# begining code below....
# import AWS module
import-module AWSPowerShell.NetCore

#$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy-mmss')
$skyhookformatteddate = (Get-Date).AddDays(0).ToString('yyyy-MM-dd hh:mm:ss')
$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy')

# SMTP server
#$smtpserver = "ice-dhs-gov.mail.protection.outlook.com"

#rm ".\*.csv"
rm ".\AzureVMCreationandSKUsize.json"

# Pull info script
$subscriptions = Get-AzSubscription -SubscriptionName "mgmt-ops"
    foreach($subscription in $subscriptions)
    {
        $context = Select-AzSubscription -Subscription $subscription.Id
        set-azcontext $context
        $VMs = Get-AzVM | Where-Object {($_.name -eq "a1sprmgt001")}

        foreach ($VM in $VMs)
        {
            $osStorageProfile = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name 

            $OSDisk = Get-AzDisk -DiskName $osStorageProfile.StorageProfile.OsDisk.name -ResourceGroupName $osStorageProfile.ResourceGroupName

            $nicfound = Get-AzNetworkInterface -ResourceId $vm.NetworkProfile.NetworkInterfaces.id

            $objects = -join( $subscription.Name +";"+ $VM.Name +";"+ $VM.location +";"+ $nicfound.IpConfigurations.PrivateIpAddress +";"+ $VM.ResourceGroupName +";"+ $osdisk.TimeCreated +";"+ $VM.HardwareProfile.VmSize +";"+ $VM.tags.Values)

            #write-host $objects
            #$objects | Out-File ".\AzureVMCreationandSKUsize$date.csv"  -Append 

            $objects | Export-Excel ".\AzureVMCreationandSKUsize_$date.xlsx"  -Append 
        }


    }

###### workspace##############
$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy')
$path = Get-Location
$filename = -join ($path ,".\AzureVMCreationandSKUsize_$date.xlsx")
$Excel = Open-ExcelPackage -Path $filename -Create
Add-Worksheet -ExcelPackage $Excel -WorksheetName 'AzureVMCreationandSKUsize' -MoveToStart
Set-ExcelRow -ExcelPackage $excel -WorksheetName 'AzureVMCreationandSKUsize' -HeadingBold

$ws = $excel.Workbook.Worksheets['AzureVMCreationandSKUsize']


$ws.Cells['A1'].Value = 'Subscription'
$ws.Cells['B1'].Value = 'Instance Name'
$ws.Cells['C1'].Value = 'Location'
$ws.Cells['D1'].Value = 'IP Address'
$ws.Cells['E1'].Value = 'Resource Group'
$ws.Cells['F1'].Value = 'Creation Date'
$ws.Cells['G1'].Value = 'SKU'
$ws.Cells['H1'].Value = 'Application'
$ws.Cells['I1'].Value = 'BillingCode'
$ws.Cells['J1'].Value = 'Environment'
$ws.Cells['K1'].Value = 'FISMAID' 
$ws.Cells['L1'].Value = 'Name'
$ws.Cells['M1'].Value = 'Portfolio'


$row =2
$column =1
$subscription = Get-AzSubscription -SubscriptionName 'mgmt-ops'
$ws.Cells[$row, $column].Value = $subscription.Name
$Column++
$ws.Cells[$row, $column].Value = $VM.Name
$Column++
$ws.Cells[$row, $column].Value = $VM.Location
$Column++
$ws.Cells[$row, $column].Value = $nicfound.IpConfigurations.PrivateIpAddress
$Column++
$ws.Cells[$row, $column].Value = $VM.ResourceGroupName
$Column++
$ws.Cells[$row, $column].Value = $osdisk.TimeCreated.ToString('MM/dd/yyyy')
$Column++
$ws.Cells[$row, $column].Value = $VM.HardwareProfile.VmSize
$Column++
$ws.Cells[$row, $column].Value = $VM.Tags.Application
$Column++
$ws.Cells[$row, $column].Value = $VM.Tags.BillingCode
$Column++
$ws.Cells[$row, $column].Value = $VM.Tags.Billingpoc
$Column++
$ws.Cells[$row, $column].Value = $VM.Tags.Environment


Export-Excel -ExcelPackage $Excel -WorksheetName 'AzureVMCreationandSKUsize' -AutoSize -FreezeTopRow -BoldTopRow -AutoFilter -Calculate #| Set-ExcelRow -ExcelPackage $excel -WorksheetName 'AzureVMCreationandSKUsize' -Heading $Headers -HeadingBold

#end of loop, increment $row++



# Before the loops create, header definition
What-TheFK

# DO STUFF and end th eloop with this
$objects = ( $subscription.Name, $VM.Name, $VM.location, $nicfound.IpConfigurations.PrivateIpAddress, $VM.ResourceGroupName, $osdisk.TimeCreated, $VM.HardwareProfile.VmSize, $VM.tags.Values)

# use -Passthru inside a loop but otherwise this call closes the XLSX$
Export-Excel -ExcelPackage $Excel -WorksheetName 'AzureVMCreationandSKUsize' -AutoSize -FreezeTopRow -BoldTopRow -AutoFilter -Calculate #| Set-ExcelRow -ExcelPackage $excel -WorksheetName 'AzureVMCreationandSKUsize' -Heading $Headers -HeadingBold


Close-ExcelPackage -ExcelPackage $Excel -SaveAs $filename -Calculate


$jsontext = '
{
"frequency": "hourly", 
"name": "All Azure Gov Cloud Instances and Tags",
"format": "CSV", 
"file_type": ".csv", 
"file_name": "AzureVMCreationandSKUsize2bereplaced.csv",
"latest_run": "date",
"description": "Report fetches all Azure instances and their tag values."
}
'

$jsontext = $jsontext -replace "date", "$skyhookformatteddate"
$jsontext = $jsontext -replace "2bereplaced", "$date"

$jsontext | Out-File ".\AzureVMCreationandSKUsize.json" 
#write-output $jsontext

# Get keys for AWS S3 from AZ KeyVault
$context = select-azsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
set-azcontext $context

# Creds
$awsreportsaccesskey = Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "awsreportsaccesskey" -AsPlainText
$awsreportssecretkey = Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "awsreportssecretkey" -AsPlainText

Write-S3Object -BucketName "ice-skyhook-data" -file ".\AzureVMCreationandSKUsize$date.csv" -key "AzureVMCreationandSKUsize$date.csv" -AccessKey $awsreportsaccesskey -SecretKey $awsreportssecretkey -region us-gov-west-1 -force
Write-S3Object -BucketName "ice-skyhook-data" -file ".\AzureVMCreationandSKUsize.json" -key "AzureVMCreationandSKUsize.json" -AccessKey $awsreportsaccesskey -SecretKey $awsreportssecretkey -region us-gov-west-1 -force


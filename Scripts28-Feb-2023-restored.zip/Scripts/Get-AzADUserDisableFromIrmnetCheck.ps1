#$users = get-azaduser 

$users = get-azaduser | Where-Object {($_.UserPrincipalName -match "icegovazure.onmicrosoft.com")}
$user2disable = @()
$irmnetzzaccountdisabled =@()
$icegovazureaccount2disable=@()

$usersearch = $users
foreach ($usertofind in $usersearch)
    {
        Write-Output "searching for: " $usertofind.UserPrincipalName
        $userchecker = Get-ADUser -Filter {(GivenName -like $usertofind.GivenName) -and (Surname -like $usertofind.Surname)}
        foreach ($usercheck in $userchecker)
            {
                $usercheckerzz = $usercheck | Where-Object {$usercheck.name -match "zz"}
                Write-Output "searching for account with associated zz: " $usercheckerzz.UserPrincipalName

                if ($usercheckerzz.Enabled -eq $false)
                    {
                        Write-Output $usercheckerzz.UserPrincipalName "is found to be disabled"
                        $irmnetzzaccountdisabled += ($usercheckerzz.UserPrincipalName)
                        $icegovazureaccount2disable += ($usertofind.UserPrincipalName)

                    }

            }
    }

$irmnetzzaccountdisabled | sort | Out-GridView
$icegovazureaccount2disable | sort | Out-GridView


#for each user found get the irmnet ad user account state
#if user account state is disabled add to array of accounts found disabled
#disable the accounts found disabled in irmnet 
<# 
This script is provided as a service from Microsoft and is only a example of the function contained therein.
Please modify to suit your environment before running it.

.SYNOPSIS
Automates alerting on Recovery Service Vaults
.PARAMETER RG
This the name of the Resource Group containing the desired Recovery Servies Vault
.DESCRIPTION
This script was created by Drew Cornutt from Microsoft and it automates the creation of Azure Site 
Recovery alerts that if manually done would have to be configured on each Recovery Services Vault individually.
.EXAMPLE
.\RSV-Alerts.ps1 AZ-GOV-PRD-FPS-AZ
#>

[CmdletBinding()]
param (
    #input the RG name
    [Parameter(mandatory = $true)]
    [string]
    $RG,
    
    # Parameter help description
    [Parameter(mandatory = $false)]
    [string]
    $RSVName,

    # Parameter help description
    [Parameter(mandatory = $false)]
    [array]
    $RSVNames

)

# $RG = 'AZ-GOV-MGMT-TOOLS-DR-AZ'
$RSVNames = (Get-AzRecoveryServicesVault -ResourceGroupName $RG).Name
$List = @(
    "Drew.Cornutt@associates.ice.dhs.gov"
    "sanjeev.punn@associates.ice.dhs.gov"
    "Giles.C.Hjort-Tyson@associates.ice.dhs.gov"
    "Benjamin.J.Findley@associates.ice.dhs.gov"
    "Steven.LeCompte@associates.ice.dhs.gov"
    "Christopher.Starrs@associates.ice.dhs.gov"
    "BrieAnne.J.Julian@associates.ice.dhs.gov"
    "Richard.P.Inzunza@ice.dhs.gov"
    "Pamela.Christopher-Jones@ice.dhs.gov"
    "ae-kyong.morrell@ice.dhs.gov"
)

foreach ($RSVName in $RSVNames) {
    
    #Get Recovery Services Vault Context
    $RSV = (Get-AzRecoveryServicesVault -Name $RSVName -ResourceGroupName $RG)

    Set-AzRecoveryServicesAsrVaultContext -Vault $RSV 

    #Set Site Recovery Service Alert Notifications
    Set-AzRecoveryServicesAsrAlertSetting -CustomEmailAddress $List

}


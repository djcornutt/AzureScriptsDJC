
$subscriptions = Get-AzSubscription
foreach ($subscription in $subscriptions) {
    Select-AzSubscription -Subscription $subscription.Id

    $context = Get-AzContext
    Set-AzContext -Context $context

<#
$vnetObjs = Get-AzVirtualNetwork 
foreach ($vnetobj in $vnetObjs) {
    $resultvNet = "vNet Name: " + $vnetObj.Name
    $resultvNet
    $resultPeering = "Peering: " + (Get-AzVirtualNetworkPeering -Name "*" -VirtualNetwork $vnetObj.Name -ResourceGroupName $vnetobj.ResourceGroupName | Select-Object -ExpandProperty Name)
    $resultPeering
    if ($vnetobj.DhcpOptions.DnsServers){
        $resultDNS = "DNS Server: " + $vnetobj.DhcpOptions.DnsServers
        }
    else {
        $resultDNS = "DNS Server: Azure Default" 
        }
    $resultDNS
    $resultIPAddress = $vnetobj | Get-AzVirtualNetworkSubnetConfig | Select-Object Name,AddressPrefix
    $resultIPAddress
    $a 
    }  
  #>  
############################################################################
    $networks = Get-AzVirtualNetwork | ForEach-Object {
        New-Object PSObject -Property @{        
                        
            AddressSpace = $_.AddressSpace.AddressPrefixes -join ';'
            Subnets      = $_.subnets.name -join ';'
            Name         = $_.name
            Location = $_.Location
            Subscription = $context.subscription.name
            ResourceGroupName = $_.ResourceGroupName
        }
    }
    $networks | Export-Csv -NoTypeInformation -Append AllVnets8-Feb-2023.csv
}

#$vnets | convertto-csv | Out-File -append AllVnets.csv

            #Peerings = $_.VirtualNetworkPeerings.name -join ';'

# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

####START OF SCRIPT######

<# This script searches all subs and RGs to identify disk snapshots 
   and evaluates how old they are. If greater than 30 days old, a warning email is sent.
   At 60 days another warning is sent stating it will be deleting at 90 with no further warning.
   Any resource without a POC tag populated will go to Rick

   Drew Cornutt - Microsoft
#>

#sets dates to be used for warning/deletion evaluation
$date30 = (Get-Date).AddDays(-30).ToUniversalTime()
$date60 = (Get-Date).AddDays(-60).ToUniversalTime()
$date90 = (Get-Date).AddDays(-90).ToUniversalTime()

#SMTP relay 
$smtpserver = 'ice-dhs-gov.mail.protection.outlook.com'


# Only run in these 2 subs
$subscriptions = @(
    "Prod-Ops",
    "Mgmt-Ops"
)

foreach ($subscription in $subscriptions) {
    select-azsubscription -SubscriptionName $subscription

    #grabs all RG's --- *****comment out test RG when going PROD!!!!!*******
    $rgnames = (Get-AzResourceGroup)  | Where-Object { ($_.ResourceGroupName -match "AZ-GOV-MGMT-IC-TEST2-VA") }
      

    Foreach ($RG in $rgnames) {

        # Code below deletes any snapshot older that 90 days 


        $Snaps = Get-AzSnapshot -ResourceGroupName $RG.ResourceGroupName 

        foreach ($snap in $snaps) {

            if ($snap.TimeCreated -lt $date90) {   
        
                #query for locks and remove them.
                $Lock = (Get-AzResourceLock -resourcename $snap.name -ResourceType Microsoft.Compute/snapshots -ResourceGroupName $RG.ResourceGroupName )

                if ($Lock.LockId) { Remove-AzResourceLock -LockId $Lock.LockId -Force -ErrorAction Continue }

                else { }
                #write-host "No lock found" -ForegroundColor Magenta }


                #Remove-AzSnapshot -ResourceGroupName $RG.ResourceGroupName -SnapshotName $snap.Name -Force;

                Write-Host "$($snap.Name) in $($RG.ResourceGroupName) was older than 90 days and was deleted" -ForegroundColor Magenta
        
            }

            elseif ($snap.TimeCreated -lt $date60 -and $snap.TimeCreated -gt $date90) {

                #email a warning that the resource will be deleted soon
                
                $contacts = ($RG.Tags).ResourcePOC
                if (!$RG.Tags.ResourcePOC) {$contacts = 'Richard.Inzunza@ice.dhs.gov'}
                #$contacts = 'drew.cornutt@associates.ice.dhs.gov'
                $subject = "Azure Snapshot Delete Final Notice"
                $body = -Join ('You are the Resource POC for an Azure Snapshot named, ' + $snap.Name + ', created on, ' + $snap.TimeCreated + ', that is greater than 60 days old. If no further action is taken, it will be deleted on, ' + $snap.TimeCreated.AddDays(90).ToUniversaltime() + '. Please archive any data needed. Also, refer to this document for more information: https://confluence.ice.dhs.gov/display/IC/Azure+-+Deprovisioning ' )
                Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To $contacts -Subject $subject -body $body -SmtpServer $smtpserver
            }   

            elseif ($snap.TimeCreated -lt $date30 -and $snap.TimeCreated -gt $date60) {

                #email a warning that the resource will be deleted after next warning received
                
                $contacts = ($RG.Tags).ResourcePOC
                if (!$RG.Tags.ResourcePOC) {$contacts = 'Richard.Inzunza@ice.dhs.gov'}
                #$contacts = 'drew.cornutt@associates.ice.dhs.gov'
                $subject = 'Azure Snapshot Delete Notice'
                $body = -Join ('You are the Resource POC for an Azure Snapshot named, ' + $snap.Name + ', created on, ' + $snap.TimeCreated + ', that is greater than 30 days old. If no further action is taken, it will be deleted on, ' + $snap.TimeCreated.AddDays(90).ToUniversaltime() + ' Please archive any data needed. Also, refer to this document for more information https://confluence.ice.dhs.gov/display/IC/Azure+-+Deprovisioning ')
                Send-MailMessage -From 'ICE_Automation_Notification@ice.dhs.gov' -To $contacts -Subject $subject -body $body  -SmtpServer $smtpserver

                
            }
            

            else {
                Write-host "This snap will not be deleted because it is less than 90 days old" -ForegroundColor "Green"
            }
        }
    }
}



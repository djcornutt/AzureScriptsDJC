#Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"


 ################ Script starts here #############

$smtpserver = 'dc1-smtp.irmnet.ds2.dhs.gov'

# VMs to exclude
$VMExclusions = @(
    # MGMT-OPS Exclusions

    # Prod-OPS Exclusions

    # Prod-FPS Exclusions

     
)

# RGs to exclude
$RGExclusions = @(
    # MGMT-OPS Exclusions
    #"AZ-GOV-MGMT-IC-TEST-VA"
    #"AZ-GOV-MGMT-IC-TEST2-VA"
    #"AZ-GOV-MGMT-IC-TEST3-VA"
    "AZ-GOV-MGMT-IC-TEST4-VA"
    "AZ-GOV-MGMT-IC-TEST5-VA"
    "CSR-ICE-Transit-1"
    "CSR-ICE-Transit-2"
    "CSR-temp-VZ-NT-Transit"
    "CSR-Transit-1"
    "CSR-Transit-2"
    "DefaultResourceGroup-USBN1"
    "EQE-VPN-Transit-VA"
    "EQW-VPN-Transit-AZ"
    "ICE_Office365_ATT_VA"
    "ICEATTNB_NonTIC_VA_Backup"
    "ICENES-CLOUDSHELL"
    "ICETIC-Transit-EQX-VA"
    "ICEVzSCI_NonTIC_AZ"
    "ICEVzSCI_TIC_AZ"
    "LogAnalyticsDefaultResources"
    "NetworkWatcherRG"
    "NON-RTIC-Transit"
    "NON-RTIC-Transit-ATT"
    "Non-RTIC-Transit-AZ-VZ"
    "OCIO-Transit"
    "TIC-Transit-AZ-OneNet-ERDirect"

    # Prod-OPS Exclusions

    # Prod-FPS Exclusions
     
)

$TagName = 'ResourcePOC'

$date = (Get-Date).AddDays(0).ToString('yyyy-MM-dd')

$subscriptions = @(

    "Mgmt-Ops"
    #"Prod-Ops"
    #"Prod-FPS"
)

foreach ($subscription in $subscriptions) {

    Set-AzContext -SubscriptionName $subscription


    # Filter all RGs in this sub by ResourcePOC tag and remove exclusions
    $ResourceGroups = Get-AzResourceGroup | Where-Object { $_.Tags.Keys -match $TagName -and $_.ResourceGroupName -notin $RGExclusions }

    # narrow scope for testing

    # $ResourceGroups = Get-AzResourceGroup -name "AZ-GOV-MGMT-IC-TEST3-VA" | Where-Object { $_.Tags.Keys -match $TagName -and $_.ResourceGroupName -notin $RGExclusions }


    # Make a list of RG Names from the above script block and pass them into the For loop to evaluate VMs


    Foreach ($RG in $ResourceGroups.ResourceGroupName) {

        $VMs = (Get-AzVM -ResourceGroup $RG).Name
        
        # Start with a fresh array for each RG iteration
        $list = @()

        Foreach ($VMevaluate in $VMs) {
            $VM = get-azvm -ResourceGroupName $RG -Name $VMevaluate
            if ($VM.Extensions.name -notcontains "SiteRecovery-Windows" -and $VMExclusions -notcontains $VM.Name ) {
                #-and $VMExclusions -notcontains $VM.Name) 
                
                $list += $VM.Name + "               ", $RG
            
            }
        
            else {
            
            }
   
        }

        # After the the VMs are captured for that RG, a report is created for mailing later

        # Check for empty list so as to not create a empty txt file that gets sent to POC
        if ($list.Count -gt 0) {

            $attachments = Join-Path -Path '.' -ChildPath "VMwithNoASR-$($RG)-$($date).txt"
            #$attachments = -join("VMswithNoASR-",$($RG),"-",$date,".txt")
            $list | Out-File -FilePath ./NEW_VM_WithNo_ASR/VMwithNoASR-$($RG)-$($date).txt
            Write-Host "Report was created"

                    }
        else {
           
            Write-Output "No results found for this RG"
        }


        # Starting with a new array for the next RG
        # $list = @()

        <# RG loop is done. On to the next one#>
        Write-Host "RG loop is done"
    }

    #All RGs in this sub are done and reports created inline, now time to match the reports with the contacts listed in the BillingPOC tag

            
    # get a list of unique contacts
    $contacts = ($resourcegroups.Tags).ResourcePOC
    $contacts = ($contacts -split ',').Trim()
    $contacts = ($contacts -split ';').Trim()
    $contacts = $contacts | Select-Object -Unique

    # loop through individual contacts instead of resourcegroups
    foreach ($contact in $contacts) {
        # attach all ResourceGroups that where the individual is identified
        # $attachments = [System.Collections.ArrayList]::new()
        $resourcegroups | Where-Object { $_.Tags[$TagName] -like "*$($contact)*" } | ForEach-Object {
            $resourceGroup = $_
            # $attachments += Join-Path -Path '.' <#-ChildPath#> "VMwithNoASR-$($resourceGroup.ResourceGroupName)-$($date)-.txt"
            $attachments = "./NEW_VM_WithNo_ASR/VMwithNoASR-$($resourceGroup.ResourceGroupName)-$($date).txt"

            <# Lets send an email
            $subject = ('ALERT: Recently created VMs not in ASR')
            $body = -join ('This message is being sent from an Azure automated Function. The following VM instances are not protected through Azure Site Recovery.  If you need our assistance create a Jira ticket.')
            Send-MailMessage -From ASR_ICE_Automation_Notification@noreply.com -To $contact -Subject $subject -Body $body -SmtpServer $smtpserver -Attachments $attachments
            #>
        Write-Host "Email was sent"
        }

        # End of report sending loop
    }
    
    # clean up all files before moving on to the next sub
    Remove-Item -Path "./NEW_VM_WithNo_ASR/VMwithNoASR-*.txt"
    Write-Host "Remove all files and start the next sub"
    
    #  On to the next sub! On to the next sub! On to the next..NOW FREEZE! Somebody bring me back my money pleeez..
}
        
    # clean up all files before going home
    #Remove-Item -Path "VMwithNoASR-*.txt"

 
Write-Host "Connect to Azure US Gov?"
$response = Read-Host "Y or N"
$response.ToUpper()
If ($response -eq 'Y') { $Environment = "AzureUSGovernment" }
else { $Environment = "AzureCloud" }
Connect-AzAccount -Environment $Environment
$Subs = Get-AzSubscription
Foreach ($Sub in $Subs) {
        Write-Host ($Subs.Indexof($Sub) + 1) "-" $Sub.Name
}
$Selection = Read-Host "Subscription"
$Selection = $Subs[$Selection - 1]
Select-AzSubscription -SubscriptionObject $Selection

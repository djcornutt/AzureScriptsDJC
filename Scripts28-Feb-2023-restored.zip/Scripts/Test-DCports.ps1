

$domain = 'fqdn'

$portlist= '135','464','389','636','3268','3269','53','88','445'

$csvPath = "C:\temp\$domain - $(get-date -f yyyyMMdd-HHmmss).txt"

 

$remoteDCs = (Get-ADDomainController -Filter {IsReadOnly -eq $false} -Server $domain).Hostname

foreach ($dc in $remoteDCs)

{ echo "Testing $dc "

    foreach ($port in $portlist)

    {

        tnc $dc -port $port | Select-Object ComputerName,RemoteAddress,PingSucceeded,RemotePort,TcpTestSucceeded | Export-Csv -NoTypeInformation -Path $csvPath -Append 

    }

}
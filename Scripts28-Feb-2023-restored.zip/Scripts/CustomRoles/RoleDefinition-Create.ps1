$role = Get-AzRoleDefinition -Name "reader, contributor or whichever"
$role.Id = $null
$role.Name = "ROLENAME"
$role.Description = "Can Manage Azure Resource_X including workspaces capabilities."
$role.Actions.RemoveRange(0,$role.Actions.Count)
$role.AssignableScopes.Clear()
#example resource names
$role.actions.add("Microsoft.Resource_X/checkNameAvailability/action")
$role.actions.add("Microsoft.Resource_X/register/action")
$role.actions.add("Microsoft.Resource_X/unregister/action")
$role.actions.add("Microsoft.Resource_X/workspaces/*")
$role.actions.add("Microsoft.Resource_X/operations/read")
$role.actions.add("Microsoft.Resource_X/resourceGroups/operationStatuses/read")
$role.actions.add("Microsoft.Resource_X/privateLinkHubs/*")
$role.actions.add("Microsoft.Resource_X/locations/operationStatuses/read")
$role.actions.add("Microsoft.Resource_X/locations/operationResults/read")
$role.AssignableScopes.Add("/subscriptions/subscription GUID here")
# copy above line if more subs are in scope

Get-AzProviderOperation to list rights

New-AzRoleDefinition -Role $role

Get-AzRoleDefinition -name 'Video Indexer Restricted Viewer' | ConvertTo-Json | out-file 'Video Indexer Restricted Viewer.json'
#edit, then remove headers except Name, Description
New-AzRoleDefinition -InputFile filename.json
#if editing, use Set-AzROleDefinition, then insert the "Id": parameter below "Name":


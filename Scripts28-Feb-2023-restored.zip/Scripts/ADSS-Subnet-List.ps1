

[cmdletbinding()]            
param()            

$Sites = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Sites            

foreach ($Site in $Sites) {            

 $obj = New-Object -Type PSObject -Property (            
  @{            
   "SiteName"  = $site.Name;            
   "SubNets" = $site.Subnets;            
   "Servers" = $Site.Servers            
  }            
 )            

 $Obj | Export-Csv -Path ./ADSS-SubnetList.csv           
}

Get-ADReplicationSubnet -filter * | where-object -property Subnet,Site | Export-Csv -Path ./ADSS-SubnetList.csv

$adss = (Get-ADReplicationSubnet -filter *) 

$adss | select-object -property Name,Site | Export-Csv -Path ./ADSS-SubnetList.csv
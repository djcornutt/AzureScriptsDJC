<# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

import-module 'D:\home\site\wwwroot\Costs_and_Billing_Function_2\Modules\ImportExcel\ImportExcel.psd1'
#>
function New-CellData {

	[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Does not change system state')]
	param(
		$Range,
		$Value,
		$Format
	)
	$setFormatParams = @{
		Worksheet    = $worksheet
		Range        = $Range
		NumberFormat = $Format
	}
	if ($Value -is [string] -and $Value.StartsWith('=')) {
		$setFormatParams.Formula = $Value
	}
	else {
		$setFormatParams.Value = $Value
	}
	Set-ExcelRange @setFormatParams

}

$date = (Get-Date).AddDays(0).ToString('yyyy-MM-dd')
$weekbeforedate = (Get-Date).AddDays(-7).ToString('yyyy-MM-dd')
$smtpserver = "dc1-smtp.irmnet.ds2.dhs.gov"

$subscriptions = Get-AzSubscription
foreach ($subscription in $subscriptions) {
	Select-AzSubscription -Subscription $subscription.Id

	$context = get-azcontext
	set-azcontext -Context $context

	$TagName = 'BillingPOC'

	#gets a list of filtered RG's with the matched Tag Name
	#$resourcegroups = Get-AzResourceGroup | Where-Object { $_.Tags.Keys -match $TagName }  RESTORE FOR PROD
    #Drew's testing RGs defined 
    $resourcegroups = Get-AzResourceGroup -Name 'AZ-GOV-MGMT-IC-TEST4-VA' | Where-Object { $_.Tags.Keys -match $TagName }


	#goes through each found RG with Tag Name
	foreach ($resourcegroup in $resourcegroups) {

		$readrgtagkeys = @($resourcegroup.tags.keys[0])
		$readrgtagvalues = @($resourcegroup.tags.values[0])
		$count = 0
		Do {
			if ($readrgtagkeys[$count] -contains $tagName) {
				write-host "yes $TagName found at count" $count
				write-host "the $TagName value is " $readrgtagvalues[$count]

				#the report of the current Usage and Details for the specified RG for the specified Date range
            
				$output = Get-AzConsumptionUsageDetail -StartDate $weekbeforedate -EndDate $date -ResourceGroup $resourcegroup.ResourceGroupName -IncludeMeterDetails -IncludeAdditionalProperties
				$path = get-location
				$pathandfilexlsx = -join ($path , "\Consumptionusagedetail$date.xlsx")
                $output | Select-Object 'InstanceName', 'InstanceLocation', 'product', 'ConsumedService', 'usagestart', 'usageend', 'usagequantity','pretaxcost'| Export-Excel -Path $pathandfilexlsx -WorksheetName $resourcegroup.ResourceGroupName -AutoSize -AutoFilter -FreezeTopRow -Calculate

              

                # captures array of e-mail addresses and splits them up and filtering the addresses.
                    $emaillists = $readrgtagvalues[$count].split(";")

                        if ($emaillists.Contains(";"))
                        {
                        $emaillists = $emaillists -split (";")
                        }
                        if ($emaillists -match(' '))
                        {
                        $emaillists = $emaillists -replace(" ","")
                        }
                        if ($emaillists -match(","))
                        {
                        $emaillists = $emaillists -split(",")
                        }                   
						$subject = ("Azure ConsumptionUsageDetail")
                        $body = -join ("Hello, This is an automated message sending a document.  Attached in this e-mail is the Azure Usage and Consumption Report for the Resource Group " + $resourcegroup.ResourceGroupName + " Begining from " + $weekbeforedate + " and ending on " + $date + ".")
                        foreach ($emailindividual in $emaillists)
                            {
                                Send-MailMessage -From "ICE_Automation_Notification@noreply.com" -To $emailindividual -Subject $subject -Body $body -SmtpServer $smtpserver -Attachments $pathandfilexlsx
                            }


				#Send-MailMessage -From "ICE_Automation_Notification@noreply.com" -To $readrgtagvalues[$count] -Subject "Azure ConsumptionUsageDetail" -Body "Hello, This is an automated message sending a document.  Attached in this e-mail is the Azure Usage and Consumption Report." -SmtpServer $smtpserver -Attachments $pathandfilexlsx

				# exit Do Loop
				$count = "Exit"
				Remove-Item $pathandfilexlsx
			}
			else { $count = $count + 1 }
		}
		while ($count -ne "Exit")       
	}
}



# code below is example to multiply two columns in xlsx 
<#
				$excel = Open-ExcelPackage -Path $pathandfilexlsx
                $worksheet = $excel.Workbook.Worksheets[$resourcegroup.ResourceGroupName]
                new-celldata -Range 'I1' -value "Total" 
                $i = 2
                while($worksheet.cells["A$i"].value){
                    $range = "I$i"
                    #write-output $i
                    #Write-Output $worksheet.Cells["A$i"].value
                    $value = "=(G$i * H$i)"
   				    New-CellData -Range $range -Value $value -Format '$#,##0.00'
                    $i++
                }
				Close-ExcelPackage $excel #-show
#>






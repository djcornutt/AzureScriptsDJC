<# This script searches all subs and RGs to identify unattached disks
   and evaluates how old it is. If greater than xx days, a snaphot
   is performed then the disk is deleted. The snapshot will be named
   after the disk+'snap'+ date it was created.

   Drew Cornutt - Microsoft
#>

#sets dates to be used for warning/deletion evaluation
$date30 = (Get-Date).AddDays(-30).ToUniversalTime()
$date55 = (Get-Date).AddDays(-55).ToUniversalTime()
$date60 = (Get-Date).AddDays(-60).ToUniversalTime()

#SMTP relay
$smtpserver =  'dc1-smtp.irmnet.ds2.dhs.gov' #'ice-dhs-gov.mail.protection.outlook.com'


# Only run in these 2 subs
$subscriptions = @(
    'Prod-Ops',
    'Mgmt-Ops'
)

foreach ($subscription in $subscriptions) {
    select-azsubscription -SubscriptionName $subscription

    #grabs all RG's
    $rgnames = (Get-AzResourceGroup)  | Where-Object { ($_.ResourceGroupName -match 'AZ-GOV-MGMT-IC-TEST2-VA') }
    #$rgnames = (Get-AzResourceGroup)  | Where-Object { ($_.ResourceGroupName -like '*-VA')}

    # Copy the code that filters for RGs that are AZ-DR
    foreach ($RG in $rgnames) {




        #$RG = 'AZ-GOV-MGMT-IC-TEST2-VA'
        # Get-AzDisk -ResourceGroupName $RG | where-object {$_.DiskState -contains 'Unattached'}

        #$disk = (Get-AzDisk -ResourceGroupName AZ-GOV-MGMT-IC-TEST2-VA | where-object {$_.DiskState -contains 'Unattached'})
        $UnattachedDisks = (Get-AzDisk -ResourceGroupName $RG.ResourceGroupName | where-object { $_.DiskState -contains 'Unattached' })

        Foreach ($Disk in $UnattachedDisks) {

                
            If ($Disk.TimeCreated -lt $date60) {
                    
                #query for locks and remove them.
                $Lock = (Get-AzResourceLock -resourcename $disk.name -ResourceType Microsoft.Compute/disks -ResourceGroupName $RG.ResourceGroupName )
                if ($Lock.LockId) {Remove-AzResourceLock -LockId $Lock.LockId -Force -ErrorAction Continue}

                else { }

                Start-Sleep -Seconds 5
        
                #snap the disk before deleting with the snap's display name the disk and timecreated
                $snapConfig = New-AzSnapshotConfig -SourceUri $Disk.Id -CreateOption Copy -Location $Disk.Location
                $snapshotname = ($disk.name + 'snap' + $Disk.TimeCreated.ToString('yyyyMMddhhmm'))
                $snapshotname = ($snapshotname.SubString(0,[math]::min(79,$snapshotname.length) ))
                New-AzSnapshot  -ResourceGroupName $RG.ResourceGroupName -SnapshotName $snapshotname -Snapshot $snapConfig

                Write-Host "Created snapshot $($snapshotname) successfully"

                Write-Host 'Disk is older than 90 days. A snaphot will be created and disk deleted.' -ForegroundColor Red

                #uncomment the below only when approved and in PROD!!!
                Remove-AzDisk -ResourceGroupName $RG.ResourceGroupName -DiskName $Disk.Name -Force -ErrorAction Continue   
                Write-Host "$($disk.name) in $($RG.ResourceGroupName) was deleted" -ForegroundColor Magenta
                
            }

            elseif ($Disk.TimeCreated -lt $date55 -and $Disk.TimeCreated -gt $date60) {

                #email final warning that disk will be deleted in no more than 5 days form this notice
                
                #$contacts = ($RG.Tags).ResourcePOC
                #if (!$RG.Tags.ResourcePOC) {$contacts = 'Richard.Inzunza@ice.dhs.gov'}
                #$contacts = 'drew.cornutt@associates.ice.dhs.gov'

                $contacts = ($RG.Tags).ResourcePOC 
                if (!$RG.Tags.ResourcePOC) { $contacts = 'Richard.Inzunza@ice.dhs.gov' }
                $contacts = ($contacts -split ',').Trim()
                $contacts = ($contacts -split ';').Trim()
                $contacts = $contacts | Select-Object -Unique

                foreach ($contact in $contacts) {
                $subject = 'Unattached Azure Disk Delete Warning'
                $body = -Join ('You are the Resource POC for an Azure Disk named, ' + $disk.Name + ', created on, ' + $disk.TimeCreated + ', that is not attached to a virtual machine and is greater than 55 days old. If no further action is taken, it will be deleted on, ' + $disk.TimeCreated.AddDays(60).ToUniversaltime() + '. Please archive any data needed and delete the disk or attach the disk to a VM. A snapshot will be made prior to the deletion that will be named after the disk. In 60 days after today, that snapshot will be deleted. Please refer to this document for more information: https://confluence.ice.dhs.gov/display/IC/Azure+-+Deprovisioning ') 
                Send-MailMessage -From 'ICE_Automation_Notification@ice.dhs.gov' -To $contacts -Subject $subject -body $body -SmtpServer $smtpserver
                }

                
            }

                     
            elseif ($Disk.TimeCreated -lt $date30 -and $Disk.TimeCreated -gt $date55) {

                #email a warning that the resource will be deleted after next warning received
                
                #$contacts = ($RG.Tags).ResourcePOC
                #if (!$RG.Tags.ResourcePOC) {$contacts = 'Richard.Inzunza@ice.dhs.gov'}
                #$contacts = 'drew.cornutt@associates.ice.dhs.gov'

                $contacts = ($RG.Tags).ResourcePOC 
                if (!$RG.Tags.ResourcePOC) { $contacts = 'Richard.Inzunza@ice.dhs.gov' }
                $contacts = ($contacts -split ',').Trim()
                $contacts = ($contacts -split ';').Trim()
                $contacts = $contacts | Select-Object -Unique

                foreach ($contact in $contacts) {
                $subject = 'Unattached Azure Disk Delete Notice'
                $body = -Join ('You are the Resource POC for an Azure Disk named, ' + $disk.Name + ', created on, ' + $disk.TimeCreated + ', that is not attached to a virtual machine and is greater than 30 days old. If no further action is taken, it will be deleted on, ' + $disk.TimeCreated.AddDays(60).ToUniversaltime() + '. Please archive any data needed and delete the disk or attach the disk to a VM. Please refer to this document for more information: https://confluence.ice.dhs.gov/display/IC/Azure+-+Deprovisioning ')
                Send-MailMessage -From 'ICE_Automation_Notification@ice.dhs.gov' -To $contacts -Subject $subject -body $body -SmtpServer $smtpserver
                }
            }


            else {

                Write-Host 'This is not the disk you are looking for. (Jedi gesture)' -ForegroundColor Green
            }
                
                    

            #end disk loop
        }

        #end RG loop
    }
   
    #end sub loop
}


#$Error | Out-File -FilePath ./error.log

<#
$RGS = (get-azresourcegroup)
$rgs = (Get-AzResourceGroup)  | Where-Object { ($_.ResourceGroupName -like '*-VA')}

foreach ($MatchRG in $RGS)
{
if ( $MatchRG.resourcegroupname -like '*_VA' ) {write-host "$($MatchRG.resourcegroupname)"}
}
#>
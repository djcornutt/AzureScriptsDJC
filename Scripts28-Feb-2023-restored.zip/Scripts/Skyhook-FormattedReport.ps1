
#Vars
$date = Get-Date -format "yyyyMMddhhmm"
#$smtpserver = ''

$excel = New-Object -ComObject excel.application

$excel.visible = $True #change this to $False for AzFn

$workbook = $excel.Workbooks.Add()

$workbook.Worksheets.Add()

$workbook.Activesheet.Cells.EntireColumn.AutoFit();

$Data = $workbook.Worksheets.Item(1)

$Data.Name = 'AzureVMandSKU'

$data.Cells.Item(1, 1) = "Subscription"

$data.Cells.Item(1, 2) = "Instance Name"

$data.Cells.Item(1, 3) = "Location"

$data.Cells.Item(1, 4) = "IP Address"

$data.Cells.Item(1, 5) = "Resource Group"

$data.Cells.Item(1, 6) = "Creation Date"

$data.Cells.Item(1, 7) = "VM SKU"

$data.Cells.Item(1, 8) = "Application"

$data.Cells.Item(1, 9) = "BillingCode"

$data.Cells.Item(1, 10) = "BillingPOC"

$data.Cells.Item(1, 11) = "Environment"

$data.Cells.Item(1, 12) = "FISMAID"

$data.Cells.Item(1, 13) = "Name"

$data.Cells.Item(1, 14) = "Portfolio"

$data.Cells.Item(1, 15) = "ResourcePOC"

$intRow = 2




# you dont seriously want to do all 19 subs just yet do you?
#$subscriptions = (Get-AzSubscription).Name

#lets just do this one for now
$subscriptions = @(
	'Mgmt-Ops'
)

foreach ($subscription in $subscriptions) {     
	Set-AzContext -SubscriptionName $subscription
	Write-Host "Using $subscription" -ForegroundColor "Green"

	# For testing
	#$Resourcegroups = (get-azresourcegroup -name 'AZ-GOV-MGMT-IC-TEST3-VA')
	$Resourcegroups = Get-AzResourceGroup

	#this creates an error
	#Write-Host "Using ($Resourcegroups.ResourceGroupName)" -ForegroundColor "Green"

	foreach ($RG in $resourcegroups) {

		$RGName = $RG.ResourceGroupName
		Write-Host "Enumerating all VMs in $RGName" -ForegroundColor "Green"

		$VMs = Get-AzVM -ResourceGroupName $RG.ResourceGroupName
		foreach ($VM in $VMs)
		{
    
					

			#Lets get the IP address
			$NIC = ($VM.NetworkProfile.NetworkInterfaces.id.split("/") | Select-Object -last 1)
			$IP = (Get-AzNetworkInterface -Name $NIC).IpConfigurations.privateIPAddress

			#Lets get the VM creation date by looking at the time the OS disk was created
			$OSdisk = $VM.StorageProfile.OsDisk.Name
			$CreationDate = (Get-AzDisk -ResourceGroupName $RG.ResourceGroupName -DiskName $OSdisk).TimeCreated

			#Let's get the VM SKU
			$VMSKU = $VM.HardwareProfile.VmSize

						
			$data.Cells.Item($intRow, 1) = $subscription
						
			$data.Cells.Item($intRow, 2) = $VM.Name
						
			$data.Cells.Item($intRow, 3) = $RG.Location
						
			$data.Cells.Item($intRow, 4) = $IP
						
			$data.Cells.Item($intRow, 5) = $RG.ResourceGroupName
						
			$data.Cells.Item($intRow, 6) = $CreationDate
						
			$data.Cells.Item($intRow, 7) = $VMSKU
						
			$data.Cells.Item($intRow, 8) = $VM.Tags.Application
						
			$data.Cells.Item($intRow, 9) = $VM.Tags.BillingCode
						
			$data.Cells.Item($intRow, 10) = $VM.Tags.BillingPOC

			$data.Cells.Item($intRow, 11) = $VM.Tags.Environment

			$data.Cells.Item($intRow, 12) = $VM.Tags.FISMAID

			$data.Cells.Item($intRow, 13) = $VM.Tags.Name

			$data.Cells.Item($intRow, 14) = $VM.Tags.Portfolio

			$data.Cells.Item($intRow, 15) = $VM.Tags.ResourcePOC

						
			$intRow = $intRow + 1

						
						

		} #End of VM loop



             


	} #End of RG loop

                
} #End of Sub loop

$usedRange = $Data.UsedRange

$usedRange.EntireColumn.AutoFit() | Out-Null

$path = Get-Location
$SavePath = -Join ($path, ".\AzureVMCreationandSKUsize$date.xlsx") 


$workbook.SaveAs($Savepath)

$workbook.Close(0);

$excel.Quit()

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($Excel)

Remove-Variable excel

Stop-Process -Name EXCEL -Force 

<# email for testing purposes
$contact = 'drew.cornutt@associates.ice.dhs.gov'
$subject = "Skyhook testing"
$body = -join ('This message is being sent from an Azure automated Function. Skyhook reporting test.')
#$attachments = ".\AzureVMCreationandSKUsize-$($date).xlsx"
$attachments = ".\AzureVMCreationandSKUsize202110200451.xlsx"
$smtpserver = 'dc1-smtp.irmnet.ds2.dhs.gov'

Send-MailMessage -From Test03_ICE_Automation_Notification@noreply.com -To $contact -Subject $subject -Body $body -SmtpServer $smtpserver -Attachments $attachments
#>

# Code from the original Skyhook report that dumps the XLS to AWS

# dont run these yet
#Remove-Item ".\*.xlsx"
#Remove-Item ".\AzureVMCreationandSKUsize.json"

Import-Module AWSPowerShell.NetCore

$jsontext = '
{
"frequency": "hourly", 
"name": "All Azure Gov Cloud Instances and Tags",
"format": "XLSX", 
"file_type": ".xlsx", 
"file_name": "AzureVMCreationandSKUsize2bereplaced.xlsx",
"latest_run": "date",
"description": "Report fetches all Azure instances and their tag values."
}
'

$jsontext = $jsontext -replace "date", "$skyhookformatteddate"
$jsontext = $jsontext -replace "2bereplaced", "$date"

$jsontext | Out-File ".\AzureVMCreationandSKUsize.json" 
#write-output $jsontext

<# Get keys for AWS S3 from AZ KeyVault
$context = select-azsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
set-azcontext $context
#>

# Creds
$awsreportsaccesskey = Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "awsreportsaccesskey" -AsPlainText
$awsreportssecretkey = Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "awsreportssecretkey" -AsPlainText

Write-S3Object -BucketName "ice-skyhook-data" -file ".\AzureVMCreationandSKUsize$date.xlsx" -key "AzureVMCreationandSKUsize$date.xlsx" -AccessKey $awsreportsaccesskey -SecretKey $awsreportssecretkey -region us-gov-west-1 -force
Write-S3Object -BucketName "ice-skyhook-data" -file ".\AzureVMCreationandSKUsize.json" -key "AzureVMCreationandSKUsize.json" -AccessKey $awsreportsaccesskey -SecretKey $awsreportssecretkey -region us-gov-west-1 -force



#>


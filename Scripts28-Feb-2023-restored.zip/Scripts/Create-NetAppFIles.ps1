
#Done is both Prod-Ops and Mgmt-Ops
Register-AzResourceProvider -ProviderNamespace Microsoft.NetApp

#create a new account
$resourceGroup = "AZ-GOV-MGMT-ANF-VA"
$location = "usgovvirginia"
$anfAccountName = "azgovprdhsiavdanf01"


New-AzNetAppFilesAccount -ResourceGroupName $resourceGroup -Location $location -Name $anfAccountName

#create a Capacity Pool
$poolName = "HSI-PENLINK-AVD-ANF01"
$poolSizeBytes = 4398046511104 # 4TiB
$serviceLevel = "Standard" # Valid values are Standard, Premium and Ultra

New-AzNetAppFilesPool -ResourceGroupName $resourceGroup -Location $location -AccountName $anfAccountName -Name $poolName -PoolSize $poolSizeBytes -ServiceLevel $serviceLevel

#Create an NFS volume for Azure NetApp Files
$anfDelegation = New-AzDelegation -Name ([guid]::NewGuid().Guid) -ServiceName "Microsoft.NetApp/volumes"

$subnet = New-AzVirtualNetworkSubnetConfig -Name "gov-prd-hsi-netapp-1a" -AddressPrefix "10.168.209.32/28" -Delegation $anfDelegation
$vnet = New-AzVirtualNetwork -Name "AZ-GOV-PRD-HSI-PENLINK-VA-NETAPP" -ResourceGroupName $resourceGroup -Location $location -AddressPrefix "10.168.209.32/28" -Subnet $subnet
#$vnet = get-AzVirtualNetwork -Name "AZ-GOV-PRD-HSI-PENLINK-VA-NETAPP" -ResourceGroupName $resourceGroup 

#create the volume
$volumeSizeBytes = 1099511627776 # 100GiB
$subnetId = $vnet.Subnets[0].Id

New-AzNetAppFilesVolume -ResourceGroupName $resourceGroup `
    -Location $location `
    -AccountName $anfAccountName `
    -PoolName $poolName `
    -Name "FSLogix01" `
    -UsageThreshold $volumeSizeBytes `
    -SubnetId $subnetId `
    -CreationToken "ANFfilepath1" `
    -ServiceLevel $serviceLevel `
    -ProtocolType NFSv3



# begining code below....
# import AWS module
Import-Module AWSPowerShell.NetCore
Import-Module -name importexcel
import-module 'D:\home\site\wwwroot\Costs_and_Billing_Function_3\Modules\ImportExcel\ImportExcel.psd1'

#$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy-mmss')
$skyhookformatteddate = (Get-Date).AddDays(0).ToString('yyyy-MM-dd hh:mm:ss')
$date = get-date -format ("MM-dd-yy-HH-mm")

#these need to be in final version
#rm ".\AzureVMCreationandSKUsize.json"
#rm ".\*.xlsx" 

#create and insert headers in XLSX, pathing issue for AzFn resolved
$path = Get-Location
$path = 'D:\home\site\wwwroot\Skyhook_Reporting_Function_v2'
Remove-Item -Path "D:\home\site\wwwroot\Skyhook_Reporting_Function_v2.*.xlsx"
#$filename = -join ($path , "\AzureVMCreationandSKUsize_$date.xlsx")
$filenameandpath = -join ($path , "\AzureVMCreationandSKUsize_$date.xlsx")

$Excel = Open-ExcelPackage -Path $filename -Create
Add-Worksheet -ExcelPackage $Excel -WorksheetName 'AzureVMCreationandSKUsize' -MoveToStart
Set-ExcelRow -ExcelPackage $excel -WorksheetName 'AzureVMCreationandSKUsize' -HeadingBold

$ws = $excel.Workbook.Worksheets['AzureVMCreationandSKUsize']


$ws.Cells['A1'].Value = 'Subscription'
$ws.Cells['B1'].Value = 'Instance Name'
$ws.Cells['C1'].Value = 'Location'
$ws.Cells['D1'].Value = 'IP Address'
$ws.Cells['E1'].Value = 'Resource Group'
$ws.Cells['F1'].Value = 'Creation Date'
$ws.Cells['G1'].Value = 'VM SKU'
$ws.Cells['H1'].Value = 'Application'
$ws.Cells['I1'].Value = 'BillingCode'
$ws.Cells['J1'].Value = 'BillingPOC'
$ws.Cells['K1'].Value = 'Environment'
$ws.Cells['L1'].Value = 'FISMAID' 
$ws.Cells['M1'].Value = 'Name'
$ws.Cells['N1'].Value = 'Portfolio'
$ws.Cells['O1'].Value = 'ResourcePOC'

$row = 2

# you dont seriously want to do all 19 subs just yet do you?
$subscriptions = Get-AzSubscription

#lets just do this one for now
#$subscriptions = Get-AzSubscription -SubscriptionName "mgmt-ops"


foreach ($subscription in $subscriptions) {     
    Set-AzContext -SubscriptionName $subscription
    $subname = $subscription.Name
    Write-Host "Using $subname" -ForegroundColor "Green"

    # For testing
    #$Resourcegroups = (get-azresourcegroup -name 'AZ-GOV-MGMT-IC-TEST3-VA')
    $Resourcegroups = Get-AzResourceGroup

    #this creates an error
    #Write-Host "Using ($Resourcegroups.ResourceGroupName)" -ForegroundColor "Green"

    foreach ($RG in $resourcegroups) {

        $RGName = $RG.ResourceGroupName
        Write-Host "Enumerating all VMs in $RGName" -ForegroundColor "Green"

        $VMs = Get-AzVM -ResourceGroupName $RG.ResourceGroupName
        foreach ($VM in $VMs) {
    
			#Lets get the IP address
            $NIC = ($VM.NetworkProfile.NetworkInterfaces.id.split("/") | Select-Object -last 1)
            $IP = (Get-AzNetworkInterface -Name $NIC).IpConfigurations.privateIPAddress

            #Lets get the VM creation date by looking at the time the OS disk was created
            $OSdisk = $VM.StorageProfile.OsDisk.Name
            $CreationDate = (Get-AzDisk -ResourceGroupName $RG.ResourceGroupName -DiskName $OSdisk).TimeCreated

            #Let's get the VM SKU
            #$VMSKU = $VM.HardwareProfile.VmSize

            $column = 1
           
            $ws.Cells[$row, $column].Value = $subscription.Name
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Name
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Location
            $Column++
            $ws.Cells[$row, $column].Value = $IP
            $Column++
            $ws.Cells[$row, $column].Value = $VM.ResourceGroupName
            $Column++
            $ws.Cells[$row, $column].Value = $CreationDate.ToString('MM-dd-yyyy')
            $Column++
            $ws.Cells[$row, $column].Value = $VM.HardwareProfile.VmSize
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.Application
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.BillingCode
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.BillingPOC
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.Environment
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.FISMAID
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.Name
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.Portfolio
            $Column++
            $ws.Cells[$row, $column].Value = $VM.Tags.ResourcePOC

            $row++

            #End of VM Loop
        }
        
        

    #End of RG loop
    }

    #End of Sub loop
}

Export-Excel -ExcelPackage $Excel -WorksheetName 'AzureVMCreationandSKUsize' -AutoSize -FreezeTopRow -BoldTopRow -AutoFilter -Calculate

#website uploading
$jsontext = '
{
"frequency": "hourly", 
"name": "All Azure Gov Cloud Instances and Tags",
"format": "XLSX", 
"file_type": ".xlsx", 
"file_name": "AzureVMCreationandSKUsize2bereplaced.xlsx",
"latest_run": "date",
"description": "Report fetches all Azure instances and their tag values."
}
'

$jsontext = $jsontext -replace "date", "$skyhookformatteddate"
$jsontext = $jsontext -replace "2bereplaced", "$date"

$jsontext | Out-File ".\AzureVMCreationandSKUsize.json" 
#write-output $jsontext

# Get keys for AWS S3 from AZ KeyVault
$context = select-azsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
set-azcontext $context

# Creds
$awsreportsaccesskey = Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "awsreportsaccesskey" -AsPlainText
$awsreportssecretkey = Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "awsreportssecretkey" -AsPlainText

Write-S3Object -BucketName "ice-skyhook-data" -file "\AzureVMCreationandSKUsize_$date.xlsx" -key "\AzureVMCreationandSKUsize_$date.xlsx" -AccessKey $awsreportsaccesskey -SecretKey $awsreportssecretkey -region us-gov-west-1 -force
Write-S3Object -BucketName "ice-skyhook-data" -file ".\AzureVMCreationandSKUsize.json" -key "AzureVMCreationandSKUsize.json" -AccessKey $awsreportsaccesskey -SecretKey $awsreportssecretkey -region us-gov-west-1 -force

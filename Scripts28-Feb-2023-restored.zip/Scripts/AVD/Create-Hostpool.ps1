$RG = 'AZ-GOV-PRD-HSI-PENLINK-VA'
$HPname = 'HSI-PENLINK-AVD-HOSTPOOL-01'
$workspace = 'PENLINK01'


New-AzWvdHostPool `
-ResourceGroupName $RG `
-Name $HPname `
-WorkspaceName $workspace  `
-HostPoolType Pooled `
-Location usgovvirginia `
-LoadBalancerType DepthFirst `
-DesktopAppGroupName AVD-PENLINK `
-PreferredAppGroupType Desktop


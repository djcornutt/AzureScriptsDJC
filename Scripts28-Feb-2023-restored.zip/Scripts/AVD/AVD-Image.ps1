<#  ************************************************************************************************
    This script automates all steps in the creation of a Azure Compute Gallery Definition,
    Gallery Version using the image created in the beginning steps from the reference VM's snapshot.
    If the disk name is identical to another disk in this sub (in case of a VM pipelined clone), 
    then this script will fail. If you do not need all steps then comment out your local branch copy. 
    For example, if you are just creating a new version in the Gallery Definition. 
    
    Drew Cornutt - Microsoft
    *************************************************************************************************
    #>


#Set params
$VmRG = 'AZ-GOV-PRD-PENLINK-VA'
$ImageVm = 'a1iprmgtrhel7ami.irmnet.ds2.dhs.gov'
$imageName = 'LINUX-IMAGE-01' #give it a unique name
$ImageDefinition = 'COE-LINUX-RHEL7.9-v1.0' #give it a name that follows convention like COE-NameOfOS-versionnumberofthedefinition
$NewVersionNumber = 'x.y.z' #increment this every time or it will overwrite previous version
$region_VA = @{Name = 'usgovvirginia'; StorageAccountType = 'Standard_LRS' }
$region_AZ = @{Name = 'usgovarizona'; StorageAccountType = 'Standard_LRS' }
$targetRegions = @($region_VA, $region_AZ)
$Date = (Get-Date -format "MMddhhmm")



#   1.	Get source VM plan information: 

$vm = Get-azvm `
    -ResourceGroupName $VmRG `
    -Name $ImageVm
$vm.Plan

#   2.	Get Gallery Information 

$gallery = Get-AzGallery `
    -Name COE_Shared_Image_Gallery `
    -ResourceGroupName AZ-gov-mgmt-tools-VA

#   3. snap the image VM then create image from snapshot

$Disk = (Get-AzDisk -name $vm.StorageProfile.OsDisk.Name)

# this part removes duplicate entries caused by the pipeline using the same name every time it is run
$DiskID = ($disk.id) | Select-Object -Index 0
$DiskLocation = ($disk.Location) | Select-Object -Index 0

$snapConfig = New-AzSnapshotConfig -SourceUri $DiskId -CreateOption Copy -Location $DiskLocation 

$snapshotname = ($vm.name + '_snapshot_' + $Date)

New-AzSnapshot  -ResourceGroupName $VmRG `
    -SnapshotName $snapshotname `
    -Snapshot $snapConfig

Write-Host "Created snapshot $($snapshotname) successfully"

$snapshot = Get-AzSnapshot -ResourceGroupName $VmRG -SnapshotName $snapshotName

$imageConfig = New-AzImageConfig -Location $vm.location
$imageConfig = Set-AzImageOsDisk -Image $imageConfig -OsState Generalized -OsType Linux -SnapshotId $snapshot.Id

New-AzImage -ImageName $imageName -ResourceGroupName $VmRG -Image $imageConfig


# 4. Create the image definition:

Get-AzImage -name $imageName 

#change -Sku to a unique value
#$imageDefinition = 
New-AzGalleryImageDefinition `
    -GalleryName $gallery.Name `
    -ResourceGroupName $gallery.ResourceGroupName `
    -Location $gallery.Location `
    -Name $ImageDefinition `
    -OsState Generalized `
    -OsType Linux `
    -Publisher 'ICE' `
    -Offer 'ICE' `
    -Sku 'ICE-LINUX-01' `
    -PurchasePlanPublisher $vm.Plan.Publisher `
    -PurchasePlanProduct $vm.Plan.Product `
    -PurchasePlanName  $vm.Plan.Name

<#  

   5.	Lastly, create a new image version

#>

$OSsnapshot = @{Source = @{Id = $snapshot.Id } }

New-AzGalleryImageVersion `
    -ResourceGroupName $gallery.ResourceGroupName `
    -GalleryName $gallery.Name `
    -GalleryImageDefinitionName $ImageDefinition `
    -Name $NewVersionNumber `
    -Location $gallery.Location `
    -OsDiskImage $OSsnapshot `
    -TargetRegion $TargetRegions

# -SourceImageID $vm.Id





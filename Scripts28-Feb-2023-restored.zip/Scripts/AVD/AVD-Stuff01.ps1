$ResourceGroupName = "AZ-GOV-PRD-HSI-PENLINK-VA"
$StorageAccountName = "azgovprdplxvdiva"

 

New-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -KeyName kerb1
$key = Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -ListKerbKey | where-object{$_.Keyname -contains "kerb1"}

 

./Setspn.exe -S cifs/azgovprdplxvdiva.file.core.windows.net FSLogix-SA
#Set-ADAccountPassword -Identity FSLogix-SA$ -Reset -NewPassword (ConvertTo-SecureString -AsPlainText $key.value -Force)


# Set the feature flag on the target storage account and provide the required AD domain information
Set-AzStorageAccount `
        -ResourceGroupName $resourcegroupname `
        -Name $storageaccountname `
        -EnableActiveDirectoryDomainServicesForFile $true `
        -ActiveDirectoryDomainName "irmnet.ds2.dhs.gov" `
        -ActiveDirectoryNetBiosDomainName "irmnet" `
        -ActiveDirectoryForestName "ds2.dhs.gov" `
        -ActiveDirectoryDomainGuid "4ea5b3bd-691e-468f-899a-c43b6aebb718" `
        -ActiveDirectoryDomainsid "S-1-5-21-3516912911-3241761273-3555923892" `
        -ActiveDirectoryAzureStorageSid "S-1-5-21-3516912911-3241761273-3555923892-997027" `
        -ActiveDirectorySamAccountName $StorageAccountName `
        -ActiveDirectoryAccountType "Computer"


        $connectTestResult = Test-NetConnection -ComputerName azgovprdplxvdiva.file.core.usgovcloudapi.net -Port 445
if ($connectTestResult.TcpTestSucceeded) {
    # Mount the drive
    New-PSDrive -Name Z -PSProvider FileSystem -Root "\\azgovprdplxvdiva.file.core.usgovcloudapi.net\fslogixprofiles" -Persist
} else {
    Write-Error -Message "Unable to reach the Azure storage account via port 445. Check to make sure your organization or ISP is not blocking port 445, or use Azure P2S VPN, Azure S2S VPN, or Express Route to tunnel SMB traffic over a different port."
}
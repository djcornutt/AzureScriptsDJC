
Set-ADComputer -Identity FSLogix-SA -Server irmnet.ds2.dhs.gov -KerberosEncryptionType "AES256"


$KeyName = "kerb1" # Could be either the first or second kerberos key, this script assumes we're refreshing the first
$KerbKeys = New-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -KeyName $KeyName
$KerbKey = $KerbKeys.keys | Where-Object {$_.KeyName -eq $KeyName} | Select-Object -ExpandProperty Value
$NewPassword = ConvertTo-SecureString -String $KerbKey -AsPlainText -Force

Set-ADAccountPassword -Identity FSLogix-SA -Reset -NewPassword $NewPassword



# Get the target storage account
$storageaccount = Get-AzStorageAccount `
        -ResourceGroupName $resourcegroupname `
        -Name $storageaccountname

 

# List the directory service of the selected service account
$storageAccount.AzureFilesIdentityBasedAuth.DirectoryServiceOptions

 

# List the directory domain information if the storage account has enabled AD DS authentication for file shares
$storageAccount.AzureFilesIdentityBasedAuth.ActiveDirectoryProperties
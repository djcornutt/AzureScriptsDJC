$location = 'USGOVVIRGINIA'
$osVhdUri = "https://azgovprdlinuximg01.blob.core.usgovcloudapi.net/vhd/RHEL8_0-converted-Fixed.vhd"
$imageName = "RHEL80Image001"
$rgName = 'az-gov-mgmt-linuximage-va'


$imageConfig = New-AzImageConfig -Location $location 
$imageConfig = Set-AzImageOsDisk -Image $imageConfig -OsType Linux -OsState Generalized -BlobUri $osVhdUri 
$image = New-AzImage -ImageName $imageName -ResourceGroupName $rgName -Image $imageConfig
<# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentESTtime = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Eastern Standard Time')

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentESTtime"
#>

$smtpserver = "ice-dhs-gov.mail.protection.outlook.com"
$emailsubjectline = "Azure IAM changes on built in roles against "
$emailbody = "This alert is being sent to inform the stakeholders that Azure builtin roles have changed on "+ $date
$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy-hhmm')
$originaldate = "04-23-2021-2709"
$virtualmachinecontributornewdate = "10-05-2021-1229"
$backupoperatornewdate = "12-22-2021-0154"
$backupcontributornewdate = "11-29-2022-1238"
$siterecoverycontributornewdate = "09-20-2021-0335"
$siterecoveryoperatornewdate = "09-20-2021-0335"
$Monitoring_Contributornewdate = "02-28-2022"
# changes to local directory where json files exist
cd Function1



$Backup_Contributor = Get-AzRoleDefinition -name "Backup Contributor"
$currentrole = (get-content -Path .\Backup_Contributor_$backupcontributornewdate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Backup_Contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Backup_Contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Backup_Operator = Get-AzRoleDefinition -name "Backup Operator"
$currentrole = (get-content -Path .\Backup_Operator_$backupoperatornewdate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Backup_Operator.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Backup_Operator.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Operator.name ) -Body ($emailbody + $Backup_Operator.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Operator.name ) -Body ($emailbody + $Backup_Operator.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Operator.name ) -Body ($emailbody + $Backup_Operator.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Devtest_Labs_User = Get-AzRoleDefinition -name "Devtest Labs User"
$currentrole = (get-content -Path .\Devtest_Labs_User_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Devtest_Labs_User.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Devtest_Labs_User.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Devtest_Labs_User.name ) -Body ($emailbody + $Devtest_Labs_User.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Devtest_Labs_User.name ) -Body ($emailbody + $Devtest_Labs_User.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Devtest_Labs_User.name ) -Body ($emailbody + $Devtest_Labs_User.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Key_Vault_Contributor = Get-AzRoleDefinition -name "Key Vault Contributor"
$currentrole = (get-content -Path .\Key_Vault_Contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Key_Vault_Contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Key_Vault_Contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Key_Vault_Contributor.name ) -Body ($emailbody + $Key_Vault_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Key_Vault_Contributor.name ) -Body ($emailbody + $Key_Vault_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Key_Vault_Contributor.name ) -Body ($emailbody + $Key_Vault_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Monitoring_Contributor = Get-AzRoleDefinition -name "Monitoring Contributor"
$currentrole = (get-content -Path .\Monitoring_Contributor_$Monitoring_Contributornewdate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Monitoring_Contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Monitoring_Contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Monitoring_Contributor.name ) -Body ($emailbody + $Monitoring_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Monitoring_Contributor.name ) -Body ($emailbody + $Monitoring_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Monitoring_Contributor.name ) -Body ($emailbody + $Monitoring_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Network_contributor = Get-AzRoleDefinition -name "Network contributor"
$currentrole = (get-content -Path .\Network_contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Network_contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Network_contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Network_contributor.name ) -Body ($emailbody + $Network_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Network_contributor.name ) -Body ($emailbody + $Network_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Network_contributor.name ) -Body ($emailbody + $Network_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Private_dns_zone_contributor = Get-AzRoleDefinition -name "Private dns zone contributor"
$currentrole = (get-content -Path .\Private_dns_zone_contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Private_dns_zone_contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Private_dns_zone_contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Private_dns_zone_contributor.name ) -Body ($emailbody + $Private_dns_zone_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Private_dns_zone_contributor.name ) -Body ($emailbody + $Private_dns_zone_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Private_dns_zone_contributor.name ) -Body ($emailbody + $Private_dns_zone_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Site_recovery_contributor = Get-AzRoleDefinition -name "Site recovery contributor"
$currentrole = (get-content -Path .\Site_recovery_contributor_$siterecoverycontributornewdate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Site_recovery_contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Site_recovery_contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Site_recovery_contributor.name ) -Body ($emailbody + $Site_recovery_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Site_recovery_contributor.name ) -Body ($emailbody + $Site_recovery_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Site_recovery_contributor.name ) -Body ($emailbody + $Site_recovery_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Site_recovery_operator = Get-AzRoleDefinition -name "Site recovery operator"
$currentrole = (get-content -Path .\Site_recovery_operator_$siterecoveryoperatornewdate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Site_recovery_operator.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Site_recovery_operator.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Site_recovery_operator.name ) -Body ($emailbody + $Site_recovery_operator.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Site_recovery_operator.name ) -Body ($emailbody + $Site_recovery_operator.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Site_recovery_operator.name ) -Body ($emailbody + $Site_recovery_operator.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Sql_db_contributor = Get-AzRoleDefinition -name "Sql db contributor"
$currentrole = (get-content -Path .\Sql_db_contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Sql_db_contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Sql_db_contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Sql_db_contributor.name ) -Body ($emailbody + $Sql_db_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Sql_db_contributor.name ) -Body ($emailbody + $Sql_db_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Sql_db_contributor.name ) -Body ($emailbody + $Sql_db_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Storage_account_contributor = Get-AzRoleDefinition -name "Storage account contributor"
$currentrole = (get-content -Path .\Storage_account_contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Storage_account_contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Storage_account_contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Storage_account_contributor.name ) -Body ($emailbody + $Storage_account_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Storage_account_contributor.name ) -Body ($emailbody + $Storage_account_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Storage_account_contributor.name ) -Body ($emailbody + $Storage_account_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }


$Storage_blob_data_contributor = Get-AzRoleDefinition -name "Storage blob data contributor"
$currentrole = (get-content -Path .\Storage_blob_data_contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Storage_blob_data_contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Storage_blob_data_contributor.name)"
    }
    else
    {
    write-host "difference found"
*   Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Storage_blob_data_contributor.name ) -Body ($emailbody + $Storage_blob_data_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Storage_blob_data_contributor.name ) -Body ($emailbody + $Storage_blob_data_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Storage_blob_data_contributor.name ) -Body ($emailbody + $Storage_blob_data_contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Tag_Contributor = Get-AzRoleDefinition -name "Tag Contributor"
$currentrole = (get-content -Path .\Tag_Contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Tag_Contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Tag_Contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Tag_Contributor.name ) -Body ($emailbody + $Tag_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Tag_Contributor.name ) -Body ($emailbody + $Tag_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Tag_Contributor.name ) -Body ($emailbody + $Tag_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Virtual_Machine_Contributor = Get-AzRoleDefinition -name "Virtual Machine Contributor"
$currentrole = (get-content -Path .\Virtual_Machine_Contributor_$virtualmachinecontributornewdate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Virtual_Machine_Contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Virtual_Machine_Contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Virtual_Machine_Contributor.name ) -Body ($emailbody + $Virtual_Machine_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Virtual_Machine_Contributor.name ) -Body ($emailbody + $Virtual_Machine_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Virtual_Machine_Contributor.name ) -Body ($emailbody + $Virtual_Machine_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }

$Data_Factory_Contributor = Get-AzRoleDefinition -name "Data Factory Contributor"
$currentrole = (get-content -Path .\Data_Factory_Contributor_$originaldate.json) | ConvertFrom-Json

    if ($currentrole.Actions.count -eq $Data_Factory_Contributor.Actions.count)
    {
    Write-Host "there is no difference found comparing $($Data_Factory_Contributor.name)"
    }
    else
    {
    write-host "difference found"
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Data_Factory_Contributor.name ) -Body ($emailbody + $Data_Factory_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Richard.P.Inzunza@ice.dhs.gov" -Subject ($emailsubjectline + $Data_Factory_Contributor.name ) -Body ($emailbody + $Data_Factory_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Steven.LeCompte@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Data_Factory_Contributor.name ) -Body ($emailbody + $Data_Factory_Contributor.actions) -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject ($emailsubjectline + $Backup_Contributor.name ) -Body ($emailbody + $Backup_Contributor.actions) -SmtpServer $smtpserver
    }






Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject "IAM CHECKER" -Body "this is an automated message being sent that the code has ran" -SmtpServer $smtpserver






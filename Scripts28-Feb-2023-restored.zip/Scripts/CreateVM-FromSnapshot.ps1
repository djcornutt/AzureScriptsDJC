


#Provide the subscription Id of the subscription where you want to create Managed Disks
$subscriptionId = "29370e93-f039-4eb3-b858-7b3467603fc4"

#Provide the name of your resource group
$resourceGroupName = "AZ-GOV-MGMT-ZSCALER-AZ"

#Provide the name of the snapshot that will be used to create Managed Disks
$snapshotName = "snapshot-a2iprmgtzscn002-OSdisk"

#Provide the name of the Managed Disk
$osDiskName = "a2iprmgtzscn002-OSdisk"

#Provide the size of the disks in GB. It should be greater than the VHD file size.
$diskSize = "256"

#Provide the storage type for Managed Disk. Premium_LRS or Standard_LRS.
$storageType = "Premium_LRS"

#Provide the OS type
$osType = "linux"

#Provide the name of the virtual machine
$virtualMachineName = "a2iprmgtzscn002.irmnet.ds2.dhs.gov"


#Set the context to the subscription Id where Managed Disk will be created
az account set --subscription $subscriptionId

#Get the snapshot Id 
$snapshotId = $(az snapshot show --name $snapshotName --resource-group $resourceGroupName --query [id] -o tsv)

#Create a new Managed Disks using the snapshot Id
az disk create --resource-group $resourceGroupName --name $osDiskName --sku $storageType --size-gb $diskSize --source $snapshotId 

#Create VM by attaching created managed disks as OS
az vm create --name $virtualMachineName --resource-group $resourceGroupName --attach-os-disk $osDiskName --os-type $osType --nics "A2IPRMGTZSCN002-NIC1"

######################################################

<# 
Input Variables
$NewRGName = "NewResourceGroup"
$NewDiskName = "NewDisk"

# Create the new disk config
$NewDiskConfig = New-AzDiskConfig -Location $Location -CreateOption "Copy" -SourceResourceId $Snapshot.Id

# Create the new disk
$NewDisk = New-AzDisk -DiskName $NewDiskName -Disk $NewDiskConfig -ResourceGroupName $NewRGName

#>
$rgName = "AZ-GOV-MGMT-LINUXIMAGE-VA"
$location = "USGOVVIRGINIA"
$snapshotName = "Linux_Image"
$imageName = "RHEL_8.0"



$snapshot = Get-AzSnapshot -ResourceGroupName $rgName -SnapshotName $snapshotName

$imageConfig = New-AzImageConfig -Location $location
$imageConfig = Set-AzImageOsDisk -Image $imageConfig -OsState Generalized -OsType Linux -SnapshotId $snapshot.Id

New-AzImage -ImageName $imageName -ResourceGroupName $rgName -Image $imageConfig

################################################From Case##########

#Insert name of VM to be imaged

$vm = Get-azvm `
   -ResourceGroupName AZ-GOV-MGMT-LINUXIMAGE-VA `
   -Name a1iprmgtrhel7ami.irmnet.ds2.dhs.gov
$vm.Plan

#$vmConfig = New-AzVMConfig  -VMName $vmName  -VMSize Standard_D1_v2 |  Set-AzVMSourceImage -Id $imageDefinition.Id |  Set-AzVMPlan  -Publisher $imageDefinition.PurchasePlan.Publisher  -Product $imageDefinition.PurchasePlan.Product  -Name $imageDefinition.PurchasePlan.Name |  Add-AzVMNetworkInterface -Id $nic.Id$vm

$gallery = Get-AzGallery `
                         -Name COE_Shared_Image_Gallery `
                         -ResourceGroupName AZ-gov-mgmt-tools-VA 

$imageDefinition = New-AzGalleryImageDefinition `
                    -GalleryName $gallery.Name `
                     -ResourceGroupName $gallery.ResourceGroupName `
                     -Location $gallery.Location`
                     -Name 'COE-LINUX-V1.0'`
                     -OsState specialized `
                     -OsType Linux `
                     -Publisher 'ICE'`
                     -Offer 'ICE'`
                     -Sku 'ICE_RHEL8.0'`
                     -PurchasePlanPublisher $vm.Plan.Publisher`
                     -PurchasePlanProduct $vm.Plan.Product`
                     -PurchasePlanName $vm.Plan.Name
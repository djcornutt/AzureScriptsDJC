<# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"



<# This script is provided as a service from Microsoft and is only a example of the function contained therein.
Please modify to suit your environment before running it.
#>

$DestinationLocation = "usagovarizona"
$IncludeResourceTypes = @(
    
    #"Microsoft.Network/applicationGateways",
    "Microsoft.Network/loadBalancers",
    "Microsoft.Network/networkSecurityGroups",
    "Microsoft.Network/loadBalancers/inboundNatRules",
    #"Microsoft.Network/applicationGateways/privateEndpointConnections",   
    "Microsoft.Compute/availabilitySets"
)



#this enumnerates all subs and creates our Resource Group Name list

# This is for testing only, remove in final script  
#$subscriptions = (Get-AzSubscription -SubscriptionName Training-Ops)

$subscriptions = @(
    "Prod-Ops"
)


foreach ($subscription in $subscriptions) {     
    Set-AzContext -SubscriptionName $subscription
    Write-Host "Using $subscription"

    #            $resourcegroups = (get-azresourcegroup -Location usgovvirginia)
    #               $resourcegroups = (get-azresourcegroup -Location usgovvirginia).ResourceGroupName
    $resourcegroups = 'AZ-GOV-PRD-HSI-SEVPAMS-VA'
    Write-Host "Using $resourcegroups"

    foreach ($SourceResourceGroupName in $resourcegroups) {
        Write-Host "Using $SourceResourceGroupName"
        #               $DestinationResourceGroupName = $SourceResourceGroupName.Substring(0,$SourceResourceGroupName.Length-3) + "-DR-AZ"
        $DestinationResourceGroupName = 'AZ-GOV-PRD-HSI-SEVPAMS-AZ'
                    
        write-host $SourceResourceGroupName "is matched with" $DestinationResourceGroupName


        # this is where RG names pass down into the meat of the script             
            
 
        # load list of resources to extract
        $SourceTemplateFilepath = ".\" + $SourceResourceGroupName + ".json"
        # $DestinationTemplateFilepath = $env:TEMP + "/" + $DestinationResourceGroupName + ".json", took out the prefixes

        Write-Host "Creating template of current resources to $SourceTemplateFilepath"
        if ($SourceResourceNames) {
            if ($IncludeResourceTypes -or $ExcludeResourceTypes) {
                Write-Warning "-IncludeResourceTypes and -ExcludeResourceTypes parameters will be ignored when using -SourceResourceNames"
            }
            $resources = Get-AzResource -ResourceGroupName $SourceResourceGroupName | Where-Object { $SourceResourceNames -contains $_.Name }

        }
        else {
            if ($IncludeResourceTypes) {
                $resources = Get-AzResource -ResourceGroupName $SourceResourceGroupName | Where-Object { $IncludeResourceTypes -contains $_.ResourceType }

            }
            # we dont need this but it's an option when doing excludes
            else {
                $resources = Get-AzResource -ResourceGroupName $SourceResourceGroupName
            }

            # filter out ExcludeResourceTypes
            $resources = $resources | Where-Object { $ExcludeResourceTypes -notcontains $_.ResourceType }
    
        }

        # export resources above into a template
        $resourceIds = $Resources.ResourceId
        $null = Export-AzResourceGroup -Path $SourceTemplateFilepath -ResourceGroupName $SourceResourceGroupName -Resource $resourceIds -SkipAllParameterization -Force -ErrorAction Stop
        $template = Get-Content $SourceTemplateFilepath | ConvertFrom-Json

        # process all resources
          $finalResources = @()
        Write-Verbose "Processing resources and updating for new resource group & location"

        foreach ($resource in $template.resources) {

            Write-Host "Processing $($resource.Name)"

            # update top level resource with location
            if ($resource.Location -and $DestinationLocation) {
                $resource.Location = $DestinationLocation
            }

            # required update differ by resource type
            if ($resource.Type -eq "Microsoft.Compute/availabilitySets") {
                #$resource.dependsOn = $null
                #$resource.properties.virtualMachines = $null

            }
    
    
            elseif ($resource.Type -eq "Microsoft.Network/applicationGateways") {
                # remove NIC dependencies as NIC contains the applicationGateway. the NIC ID's on the LB are reference only
                # if ($resource.dependsOn) {
                #     [array] $resource.dependsOn = $resource.dependsOn | Where-Object { $_ -notlike "*Microsoft.Network/networkInterfaces*" }
                #  }

              <#  if ($KeepSourceIPAddresses) {
                    foreach ($ipconfig in $resource.Properties.frontendIPConfigurations) {
                        if ($ipConfig.properties.privateIPAddress -and $ipconfig.properties.subnet) {
                            $ipConfig.properties.privateIPAllocationMethod = 'Static' 
                        }
                    }
                } #>
            }
            elseif ($resource.Type -eq "Microsoft.Network/loadBalancers") {
                # remove NIC dependencies as NIC contains the loadBalancer. the NIC ID's on the LB are reference only
                #   if ($resource.dependsOn) {
                #       [array] $resource.dependsOn = $resource.dependsOn | Where-Object { $_ -notlike "*Microsoft.Network/networkInterfaces*" }
            }

            if ($KeepSourceIPAddresses) {
                foreach ($ipconfig in $resource.Properties.frontendIPConfigurations) {
                    if ($ipConfig.properties.privateIPAddress -and $ipconfig.properties.subnet) {
                        $ipConfig.properties.privateIPAllocationMethod = 'Static'
                    }
                }
            }

            # } This generated the elseif exception, all below went yellow
            elseif ($resource.Type -eq "Microsoft.Network/loadBalancers/inboundNatRules") {
                # no changes required

            
                if ($KeepSourceIPAddresses) {
                    foreach ($ipConfig in $resource.Properties.ipConfigurations) {
                        $ipConfig.properties.privateIPAllocationMethod = 'Static'
                    }
                }
            }   
            elseif ($resource.Type -eq "Microsoft.Network/networkSecurityGroups") {
                # no changes required

            }
            elseif ($resource.Type -eq "Microsoft.Network/networkSecurityGroups/securityRules") {
                # no changes required

            }


            else {
                Write-Warning "NOT SUPPORTED: $($resource.Type) will not be copied."
            }




        }
        New-AzResourceGroupDeployment -Name $SourceResourceGroupName -TemplateFile $SourceTemplateFilepath  -ResourceGroupName $DestinationResourceGroupName -Verbose

    }

}
    









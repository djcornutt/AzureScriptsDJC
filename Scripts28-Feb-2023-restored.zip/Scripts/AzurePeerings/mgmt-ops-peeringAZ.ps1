﻿$SourceVNET = $null
$SourceVNETPeerings = $null
$virtualNetwork1 = $null
$virtualNetwork2 = $null
$virtualNetwork3 = $null
$virtualNetwork4 = $null
$virtualNetwork5 = $null
$virtualNetwork6 = $null
$virtualNetwork7 = $null
$virtualNetwork8 = $null
$virtualNetwork9 = $null
$sourceVNETsubscription = $null
$virtualNetwork1subscriptionid = $null
$virtualNetwork2subscriptionid = $null
$virtualNetwork3subscriptionid = $null
$virtualNetwork4subscriptionid = $null
$virtualNetwork5subscriptionid = $null
$virtualNetwork6subscriptionid = $null
$virtualNetwork7subscriptionid = $null
$virtualNetwork8subscriptionid = $null
$virtualNetwork9subscriptionid = $null

$sourceVNETsubscription = "29370e93-f039-4eb3-b858-7b3467603fc4"

select-azurermsubscription -subscriptionid $sourceVNETsubscription

$SourceVNET = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-AZ" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-AZ" 

        $virtualNetwork1subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
        $virtualNetwork1  = Get-AzVirtualNetwork -name "Non-RTIC-Transit-AZ-VZ" -ResourceGroupName "Non-RTIC-Transit-AZ-VZ" #Fw FALSE, GW FALSE

        $virtualNetwork2subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
        $virtualNetwork2  = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-VA" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-VA" #Fw True, GW FALSE

        $virtualNetwork3subscriptionid = "ef74d5c1-8907-4c79-b7da-eb6ff067c595"
        select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
        $virtualNetwork3  = Get-AzVirtualNetwork -name "AZ-GOV-NP-ERO-AZ" -ResourceGroupName "AZ-GOV-NP-ERO-AZ" #Fw TRUE, Gw FALSE

        $virtualNetwork4subscriptionid = "d7d50c98-d5ef-47cf-bf1d-357da7594692"
        select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
        $virtualNetwork4  = Get-AzVirtualNetwork -name "AZ-GOV-NP-HSI-AZ" -ResourceGroupName "AZ-GOV-NP-HSI-AZ" #Fw TRUE, Gw FALSE

        $virtualNetwork5subscriptionid = "9ef1a393-95a9-4d0b-acc1-f51b67a68e90"
        select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
        $virtualNetwork5  = Get-AzVirtualNetwork -name "AZ-GOV-NP-MAA-AZ" -ResourceGroupName "AZ-GOV-NP-MAA-AZ" #Fw TRUE, GW FALSE

        $virtualNetwork6subscriptionid = "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
        $virtualNetwork6  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-ERO-AZ" -ResourceGroupName "AZ-GOV-PRD-ERO-AZ" #Fw TRUE, GW FALSE

        $virtualNetwork7subscriptionid = "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        select-azurermsubscription -subscriptionid $virtualNetwork7subscriptionid
        $virtualNetwork7  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-HSI-AZ" -ResourceGroupName "AZ-GOV-PRD-HSI-AZ" #FW TRUE, GW FALSE

        $virtualNetwork8subscriptionid = "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        select-azurermsubscription -subscriptionid $virtualNetwork8subscriptionid
        $virtualNetwork8  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-MAA-AZ" -ResourceGroupName "AZ-GOV-PRD-MAA-AZ" #FW TRUE, GW FALSE

        #$virtualNetwork9subscriptionid = ""
        #select-azurermsubscription -subscriptionid $virtualNetwork9subscriptionid
        #$virtualNetwork9  = Get-AzVirtualNetwork -name "" -ResourceGroupName "" #Fw Check

#Select Source Subscription to initiate removal
select-azurermsubscription -subscriptionid $sourceVNETsubscription











Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-Non-RTIC-Transit-AZ-VZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-NP-ERO-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-NP-HSI-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-NP-MAA-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-PRD-ERO-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-PRD-HSI-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-PRD-MAA-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
#Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName

#Remove Cross or same subscription Peers:
select-azurermsubscription -subscriptionid $sourceVNETsubscription


select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "Non-RTIC-Transit-AZ-VZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName  -Force
select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-ERO-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-HSI-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-MAA-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-ERO-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork7subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-HSI-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork7.Name -ResourceGroupName $virtualnetwork7.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork8subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $virtualnetwork8.Name -ResourceGroupName $virtualnetwork8.ResourceGroupName -Force
#select-azurermsubscription -subscriptionid $virtualNetwork9subscriptionid
#Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork9.Name -ResourceGroupName $virtualnetwork9.ResourceGroupName -Force




#
# Make CIDR changes or other changes that require Peering breakage
#











#Select Source Subscription to initiate recreation of peerings
select-azurermsubscription -subscriptionid  $sourceVNETsubscription
$SourceVNETPeerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $SourceVNET.name -ResourceGroupName $SourceVNET.ResourceGroupName

Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-Non-RTIC-Transit-AZ-VZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork1.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-MGMT-TOOLS-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork2.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-NP-ERO-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork3.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-NP-HSI-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork4.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-NP-MAA-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork5.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-PRD-ERO-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork6.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-PRD-HSI-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork7.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-PRD-MAA-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork8.Id
#Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork9.Id

select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "Non-RTIC-Transit-AZ-VZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualNetwork1 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork1Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName -Name "Non-RTIC-Transit-AZ-VZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork1Peerings.AllowForwardedTraffic = $false
$VirtualNetwork1Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork1Peerings

select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork2 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork2Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork2Peerings.AllowForwardedTraffic = $true
$VirtualNetwork2Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork2Peerings

select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-ERO-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork3 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork3Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName -Name "AZ-GOV-NP-ERO-AZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork3Peerings.AllowForwardedTraffic = $true
$VirtualNetwork3Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork3Peerings

select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-HSI-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork4 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork4Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName -Name "AZ-GOV-NP-HSI-AZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork4Peerings.AllowForwardedTraffic = $true
$VirtualNetwork4Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork4Peerings

select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-MAA-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork5 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork5Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName -Name "AZ-GOV-NP-MAA-AZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork5Peerings.AllowForwardedTraffic = $true
$VirtualNetwork5Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork5Peerings

select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-ERO-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork6 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork6Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName -Name "AZ-GOV-PRD-ERO-AZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork6Peerings.AllowForwardedTraffic = $true
$VirtualNetwork6Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork6Peerings

select-azurermsubscription -subscriptionid $virtualNetwork7subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-HSI-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork7 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork7Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork7.Name -ResourceGroupName $virtualnetwork7.ResourceGroupName -Name "AZ-GOV-PRD-HSI-AZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork7Peerings.AllowForwardedTraffic = $true
$VirtualNetwork7Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork7Peerings

select-azurermsubscription -subscriptionid $virtualNetwork8subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-AZ-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetwork $virtualnetwork8 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork8Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork8.Name -ResourceGroupName $virtualnetwork8.ResourceGroupName -Name "AZ-GOV-PRD-MAA-AZ-to-AZ-GOV-MGMT-TOOLS-AZ"
$virtualNetwork8Peerings.AllowForwardedTraffic = $true
$VirtualNetwork8Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork8Peerings

#select-azurermsubscription -subscriptionid $virtualNetwork9subscriptionid
#Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork9.Name -RemoteVirtualNetworkId $SourceVNET.Id
#$VirtualNetwork9Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork9.Name -ResourceGroupName $virtualnetwork9.ResourceGroupName -Name ""
#$virtualNetwork9Peerings.AllowForwardedTraffic = $true
#$VirtualNetwork9Peerings.AllowGatewayTransit = $false
#Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork9Peerings













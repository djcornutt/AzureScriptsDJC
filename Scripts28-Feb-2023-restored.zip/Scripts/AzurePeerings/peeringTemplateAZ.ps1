﻿$SourceVNET = $null
$SourceVNETPeerings = $null
$virtualNetwork1 = $null
$virtualNetwork2 = $null
$virtualNetwork3 = $null
$virtualNetwork4 = $null
$virtualNetwork5 = $null
$virtualNetwork6 = $null
$virtualNetwork7 = $null
$virtualNetwork8 = $null
$virtualNetwork9 = $null

$sourceVNETsubscription = "29370e93-f039-4eb3-b858-7b3467603fc4"

select-azurermsubscription -subscriptionid $sourceVNETsubscription

$SourceVNET = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-AZ" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-AZ" 

        $virtualNetwork1subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $
        $virtualNetwork1  = Get-AzVirtualNetwork -name "Non-RTIC-Transit-AZ-VZ" -ResourceGroupName "Non-RTIC-Transit-AZ-VZ" #Fw FALSE, GW FALSE

        $virtualNetwork2subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
        $virtualNetwork2  = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-VA" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-VA" #Fw True, GW FALSE

        $virtualNetwork3subscriptionid = "ef74d5c1-8907-4c79-b7da-eb6ff067c595"
        select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
        $virtualNetwork3  = Get-AzVirtualNetwork -name "AZ-GOV-NP-ERO-AZ" -ResourceGroupName "" #Fw TRUE, Gw FALSE

        $virtualNetwork4subscriptionid = "d7d50c98-d5ef-47cf-bf1d-357da7594692"
        select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
        $virtualNetwork4  = Get-AzVirtualNetwork -name "AZ-GOV-NP-HSI-AZ" -ResourceGroupName "AZ-GOV-NP-HSI-AZ" #Fw check, Gw Check

        $virtualNetwork5subscriptionid = ""
        select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
        $virtualNetwork5  = Get-AzVirtualNetwork -name "" -ResourceGroupName "" #Fw Check

        $virtualNetwork6subscriptionid = ""
        select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
        $virtualNetwork6  = Get-AzVirtualNetwork -name "" -ResourceGroupName "" #Fw Check

        $virtualNetwork7subscriptionid = ""
        select-azurermsubscription -subscriptionid $virtualNetwork7subscriptionid
        $virtualNetwork7  = Get-AzVirtualNetwork -name "" -ResourceGroupName "" #Fw Check

        $virtualNetwork8subscriptionid = ""
        select-azurermsubscription -subscriptionid $virtualNetwork8subscriptionid
        $virtualNetwork8  = Get-AzVirtualNetwork -name "" -ResourceGroupName "" #Fw Check

        $virtualNetwork9subscriptionid = ""
        select-azurermsubscription -subscriptionid $virtualNetwork9subscriptionid
        $virtualNetwork9  = Get-AzVirtualNetwork -name "" -ResourceGroupName "" #Fw Check

#Select Source Subscription to initiate removal
select-azurermsubscription -subscriptionid ""


Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName

#Remove Cross or same subscription Peers:
select-azurermsubscription -subscriptionid ""


select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork7subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork7.Name -ResourceGroupName $virtualnetwork7.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork8subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork8.Name -ResourceGroupName $virtualnetwork8.ResourceGroupName
select-azurermsubscription -subscriptionid $virtualNetwork9subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "" -VirtualNetworkName $virtualnetwork9.Name -ResourceGroupName $virtualnetwork9.ResourceGroupName




#
# Make CIDR changes or other changes that require Peering breakage
#



#Select Source Subscription to initiate recreation of peerings
select-azurermsubscription -subscriptionid ""
$SourceVNETPeerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $SourceVNET.name -ResourceGroupName $SourceVNET.ResourceGroupName

Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork1.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork2.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork3.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork4.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork5.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork6.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork7.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork8.Id
Add-AzureRmVirtualNetworkPeering -Name '' -VirtualNetwork $SourceVNET.Name -RemoteVirtualNetworkId $virtualNetwork9.Id

select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualNetwork1.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork1Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName -Name ""
$virtualNetwork1Peerings.AllowForwardedTraffic = $false
$VirtualNetwork1Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork1Peerings

select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork2.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork2Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName -Name ""
$virtualNetwork2Peerings.AllowForwardedTraffic = $true
$VirtualNetwork2Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork2Peerings

select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork3.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork3Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName -Name ""
$virtualNetwork3Peerings.AllowForwardedTraffic = $true
$VirtualNetwork3Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork3Peerings

select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork4.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork4Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName -Name ""
$virtualNetwork4Peerings.AllowForwardedTraffic = $true
$VirtualNetwork4Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork4Peerings

select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork5.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork5Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName -Name ""
$virtualNetwork5Peerings.AllowForwardedTraffic = $true
$VirtualNetwork5Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork5Peerings

select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork6.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork6Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName -Name ""
$virtualNetwork6Peerings.AllowForwardedTraffic = $true
$VirtualNetwork6Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork6Peerings

select-azurermsubscription -subscriptionid $virtualNetwork7subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork7.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork7Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork7.Name -ResourceGroupName $virtualnetwork7.ResourceGroupName -Name ""
$virtualNetwork7Peerings.AllowForwardedTraffic = $true
$VirtualNetwork7Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork7Peerings

select-azurermsubscription -subscriptionid $virtualNetwork8subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork8.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork8Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork8.Name -ResourceGroupName $virtualnetwork8.ResourceGroupName -Name ""
$virtualNetwork8Peerings.AllowForwardedTraffic = $true
$VirtualNetwork8Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork8Peerings

select-azurermsubscription -subscriptionid $virtualNetwork9subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "" -VirtualNetwork $virtualnetwork9.Name -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork9Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork9.Name -ResourceGroupName $virtualnetwork9.ResourceGroupName -Name ""
$virtualNetwork9Peerings.AllowForwardedTraffic = $true
$VirtualNetwork9Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork9Peerings













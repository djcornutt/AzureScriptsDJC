﻿$SourceVNET = $null
$SourceVNETPeerings = $null
$virtualNetwork1 = $null
$virtualNetwork2 = $null
$virtualNetwork3 = $null
$virtualNetwork4 = $null
$virtualNetwork5 = $null
$virtualNetwork6 = $null
$virtualNetwork7 = $null
$virtualNetwork8 = $null
$virtualNetwork9 = $null
$sourceVNETsubscription = $null
$virtualNetwork1subscriptionid = $null
$virtualNetwork2subscriptionid = $null
$virtualNetwork3subscriptionid = $null
$virtualNetwork4subscriptionid = $null
$virtualNetwork5subscriptionid = $null
$virtualNetwork6subscriptionid = $null
$virtualNetwork7subscriptionid = $null
$virtualNetwork8subscriptionid = $null
$virtualNetwork9subscriptionid = $null


select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
$SourceVNET = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-VA" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-VA" 

        select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
        $virtualNetwork1  = Get-AzVirtualNetwork -name "NON-RTIC-Transit" -ResourceGroupName "NON-RTIC-Transit" #Fw check, GW check

        select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        $virtualNetwork2  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-ERO-VA" -ResourceGroupName "AZ-GOV-PRD-ERO-VA" #Fw check, GW check

        select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        $virtualNetwork3  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-MAA-VA" -ResourceGroupName "AZ-GOV-PRD-MAA-VA" #Fw check, Gw Check

        select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
        $virtualNetwork4  = Get-AzVirtualNetwork -name "NON-RTIC-Transit-ATT" -ResourceGroupName "NON-RTIC-Transit-ATT" #Fw check, Gw Check

        select-azurermsubscription -subscriptionid "9ef1a393-95a9-4d0b-acc1-f51b67a68e90"
        $virtualNetwork5  = Get-AzVirtualNetwork -name "AZ-GOV-NP-MAA-VA" -ResourceGroupName "AZ-GOV-NP-MAA-VA" #Fw Check

        select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
        $virtualNetwork6  = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-AZ" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-AZ" #Fw Check

        select-azurermsubscription -subscriptionid "ef74d5c1-8907-4c79-b7da-eb6ff067c595"
        $virtualNetwork7  = Get-AzVirtualNetwork -name "AZ-GOV-NP-ERO-VA" -ResourceGroupName "AZ-GOV-NP-ERO-VA" #Fw Check

        select-azurermsubscription -subscriptionid "d7d50c98-d5ef-47cf-bf1d-357da7594692"
        $virtualNetwork8  = Get-AzVirtualNetwork -name "AZ-GOV-NP-HSI-VA" -ResourceGroupName "AZ-GOV-NP-HSI-VA" #Fw Check

        select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        $virtualNetwork9  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-HSI-VA" -ResourceGroupName "AZ-GOV-PRD-HSI-VA" #Fw Check

#Select Source Subscription to initiate removal
select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"


Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-NON-RTIC-Transit" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-ERO-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-MAA-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-NON-RTIC-Transit-ATT" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-NP-MAA-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-MGMT-TOOLS-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-NP-ERO-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-NP-HSI-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-HSI-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -force

#Remove Cross or same subscription Peers:
select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"


select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
Remove-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-ERO-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
Remove-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-ATT-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "9ef1a393-95a9-4d0b-acc1-f51b67a68e90"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "ef74d5c1-8907-4c79-b7da-eb6ff067c595"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-ERO-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork7.Name -ResourceGroupName $virtualnetwork7.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "d7d50c98-d5ef-47cf-bf1d-357da7594692"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-HSI-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork8.Name -ResourceGroupName $virtualnetwork8.ResourceGroupName  -force
select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-HSI-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $virtualnetwork9.Name -ResourceGroupName $virtualnetwork9.ResourceGroupName  -force




#
# Make CIDR changes or other changes that require Peering breakage
#



#Select Source Subscription to initiate recreation of peerings
select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
$SourceVNETPeerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $SourceVNET.name -ResourceGroupName $SourceVNET.ResourceGroupName

Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-NON-RTIC-Transit' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork1.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-ERO-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork2.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-MAA-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork3.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-NON-RTIC-Transit-ATT' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork4.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-NP-MAA-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork5.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-MGMT-TOOLS-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork6.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-NP-ERO-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork7.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-NP-HSI-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork8.Id
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-HSI-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork9.Id

select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
Add-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualNetwork1 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork1Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork1.name -ResourceGroupName $virtualnetwork1.ResourceGroupName -Name "NON-RTIC-Transit-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork1Peerings.AllowForwardedTraffic = $true
$VirtualNetwork1Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork1Peerings

select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-ERO-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork2 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork2Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork2.name -ResourceGroupName $virtualnetwork2.ResourceGroupName -Name "AZ-GOV-PRD-ERO-VA-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork2Peerings.AllowForwardedTraffic = $true
$VirtualNetwork2Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork2Peerings

select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork3 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork3Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork3.name -ResourceGroupName $virtualnetwork3.ResourceGroupName -Name "AZ-GOV-PRD-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork3Peerings.AllowForwardedTraffic = $true
$VirtualNetwork3Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork3Peerings

select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
Add-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-ATT-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork4 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork4Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork4.name -ResourceGroupName $virtualnetwork4.ResourceGroupName -Name "NON-RTIC-Transit-ATT-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork4Peerings.AllowForwardedTraffic = $true
$VirtualNetwork4Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork4Peerings

select-azurermsubscription -subscriptionid "9ef1a393-95a9-4d0b-acc1-f51b67a68e90"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork5 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork5Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork5.name -ResourceGroupName $virtualnetwork5.ResourceGroupName -Name "AZ-GOV-NP-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork5Peerings.AllowForwardedTraffic = $true
$VirtualNetwork5Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork5Peerings

select-azurermsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork6 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork6Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork6.name -ResourceGroupName $virtualnetwork6.ResourceGroupName -Name "AZ-GOV-MGMT-TOOLS-AZ-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork6Peerings.AllowForwardedTraffic = $true
$VirtualNetwork6Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork6Peerings

select-azurermsubscription -subscriptionid "ef74d5c1-8907-4c79-b7da-eb6ff067c595"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-ERO-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork7 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork7Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork7.name -ResourceGroupName $virtualnetwork7.ResourceGroupName -Name "AZ-GOV-NP-ERO-VA-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork7Peerings.AllowForwardedTraffic = $true
$VirtualNetwork7Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork7Peerings

select-azurermsubscription -subscriptionid "d7d50c98-d5ef-47cf-bf1d-357da7594692"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-NP-HSI-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork8 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork8Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork8.name -ResourceGroupName $virtualnetwork8.ResourceGroupName -Name "AZ-GOV-NP-HSI-VA-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork8Peerings.AllowForwardedTraffic = $true
$VirtualNetwork8Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork8Peerings

select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-HSI-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetwork $virtualnetwork9 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork9Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork9.name -ResourceGroupName $virtualnetwork9.ResourceGroupName -Name "AZ-GOV-PRD-HSI-VA-to-AZ-GOV-MGMT-TOOLS-VA"
$virtualNetwork9Peerings.AllowForwardedTraffic = $true
$VirtualNetwork9Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork9Peerings













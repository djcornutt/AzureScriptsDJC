﻿$SourceVNET = $null
$SourceVNETPeerings = $null
$virtualNetwork1 = $null
$virtualNetwork2 = $null
$virtualNetwork3 = $null
$virtualNetwork4 = $null
$virtualNetwork5 = $null
$virtualNetwork6 = $null




$sourceVNETsubscription = "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
select-azurermsubscription -subscriptionid $sourceVNETsubscription

$SourceVNET = Get-AzVirtualNetwork -name "AZ-GOV-PRD-MAA-VA" -ResourceGroupName "AZ-GOV-PRD-MAA-VA" 

        $virtualNetwork1subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
        $virtualNetwork1  = Get-AzVirtualNetwork -name "NON-RTIC-Transit" -ResourceGroupName "NON-RTIC-Transit" #Fw FALSE, GW FALSE

        $virtualNetwork2subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
        $virtualNetwork2  = Get-AzVirtualNetwork -name "NON-RTIC-Transit-ATT" -ResourceGroupName "NON-RTIC-Transit-ATT" #Fw True, GW FALSE

        $virtualNetwork3subscriptionid = "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
        $virtualNetwork3  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-FUNCTIONS-VA" -ResourceGroupName "AZ-GOV-PRD-FUNCTIONS-VA" #Fw TRUE, Gw FALSE

        $virtualNetwork4subscriptionid = "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
        select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
        $virtualNetwork4  = Get-AzVirtualNetwork -name "AZ-GOV-PRD-MAA-AZ" -ResourceGroupName "AZ-GOV-PRD-MAA-AZ" #Fw check, Gw Check

        $virtualNetwork5subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
        $virtualNetwork5  = Get-AzVirtualNetwork -name "AZ-GOV-MGMT-TOOLS-VA" -ResourceGroupName "AZ-GOV-MGMT-TOOLS-VA" #Fw Check

        $virtualNetwork6subscriptionid = "29370e93-f039-4eb3-b858-7b3467603fc4"
        select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
        $virtualNetwork6  = Get-AzVirtualNetwork -name "NON-RTIC-Transit-EQX-VA-Gen2" -ResourceGroupName "EQE-VPN-Transit-VA" #Fw Check


#Select Source Subscription to initiate removal
select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"

#removes all VNET peerings from this sourceVNET
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit-ATT" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-AZ-GOV-PRD-FUNCTIONS-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-AZ-GOV-PRD-MAA-AZ" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit-EQX-VA-Gen2" -VirtualNetworkName $sourceVNET.Name -ResourceGroupName $sourceVNET.ResourceGroupName -Force



#Remove Cross or same subscription Peers.  Each name is reversed.

select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-to-AZ-GOV-PRD-MAA-VA" -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit-ATT" -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-FUNCTIONS-VA-to-AZ-GOV-PRD-MAA-VA" -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-AZ-to-AZ-GOV-PRD-MAA-VA" -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-MAA-VA" -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName -Force
select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
Remove-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-EQX-VA-Gen2-to-AZ-GOV-PRD-MAA-VA" -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName -Force




#
# Make CIDR changes or other changes that require Peering breakage
#



#Select Source Subscription to initiate recreation of peerings
select-azurermsubscription -subscriptionid "3b0a673a-0dce-48c8-ae88-a276cce3c5e9"
$SourceVNETPeerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $SourceVNET.name -ResourceGroupName $SourceVNET.ResourceGroupName

Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork1.Id -AllowForwardedTraffic 
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit-ATT' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork2.Id -AllowForwardedTraffic 
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-PRD-MAA-VA-to-AZ-GOV-PRD-FUNCTIONS-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork3.Id -AllowForwardedTraffic 
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-PRD-MAA-VA-to-AZ-GOV-PRD-MAA-AZ' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork4.Id -AllowForwardedTraffic 
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-PRD-MAA-VA-to-AZ-GOV-MGMT-TOOLS-VA' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork5.Id -AllowForwardedTraffic 

#might bomb here but comment last bit to allow forwarded traffic
Add-AzureRmVirtualNetworkPeering -Name 'AZ-GOV-PRD-MAA-VA-to-NON-RTIC-Transit-EQX-VA-Gen2' -VirtualNetwork $SourceVNET -RemoteVirtualNetworkId $virtualNetwork6.Id -AllowForwardedTraffic -UseRemoteGateways




select-azurermsubscription -subscriptionid $virtualNetwork1subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-to-AZ-GOV-PRD-MAA-VA" -VirtualNetwork $virtualNetwork1 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork1Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork1.Name -ResourceGroupName $virtualnetwork1.ResourceGroupName -Name "NON-RTIC-Transit-to-AZ-GOV-PRD-MAA-VA"
$virtualNetwork1Peerings.AllowForwardedTraffic = $true
$VirtualNetwork1Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork1Peerings

select-azurermsubscription -subscriptionid $virtualNetwork2subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-to-ATT-AZ-GOV-PRD-MAA-VA" -VirtualNetwork $virtualnetwork2 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork2Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork2.Name -ResourceGroupName $virtualnetwork2.ResourceGroupName -Name "NON-RTIC-Transit-to-ATT-AZ-GOV-PRD-MAA-VA"
$virtualNetwork2Peerings.AllowForwardedTraffic = $true
$VirtualNetwork2Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork2Peerings

select-azurermsubscription -subscriptionid $virtualNetwork3subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-FUNCTIONS-VA-to-AZ-GOV-PRD-MAA-VA" -VirtualNetwork $virtualnetwork3 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork3Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork3.Name -ResourceGroupName $virtualnetwork3.ResourceGroupName -Name "AZ-GOV-PRD-FUNCTIONS-VA-to-AZ-GOV-PRD-MAA-VA"
$virtualNetwork3Peerings.AllowForwardedTraffic = $true
$VirtualNetwork3Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork3Peerings

select-azurermsubscription -subscriptionid $virtualNetwork4subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-PRD-MAA-AZ-to-AZ-GOV-PRD-MAA-VA" -VirtualNetwork $virtualnetwork4 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork4Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork4.Name -ResourceGroupName $virtualnetwork4.ResourceGroupName -Name "AZ-GOV-PRD-MAA-AZ-to-AZ-GOV-PRD-MAA-VA"
$virtualNetwork4Peerings.AllowForwardedTraffic = $true
$VirtualNetwork4Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork4Peerings

select-azurermsubscription -subscriptionid $virtualNetwork5subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-MAA-VA" -VirtualNetwork $virtualnetwork5 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork5Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork5.Name -ResourceGroupName $virtualnetwork5.ResourceGroupName -Name "AZ-GOV-MGMT-TOOLS-VA-to-AZ-GOV-PRD-MAA-VA"
$virtualNetwork5Peerings.AllowForwardedTraffic = $true
$VirtualNetwork5Peerings.AllowGatewayTransit = $false
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork5Peerings

select-azurermsubscription -subscriptionid $virtualNetwork6subscriptionid
Add-AzureRmVirtualNetworkPeering -Name "NON-RTIC-Transit-EQX-VA-Gen2-to-AZ-GOV-PRD-MAA-VA" -VirtualNetwork $virtualnetwork6 -RemoteVirtualNetworkId $SourceVNET.Id
$VirtualNetwork6Peerings = Get-AzureRmVirtualNetworkPeering -VirtualNetworkName $virtualnetwork6.Name -ResourceGroupName $virtualnetwork6.ResourceGroupName -Name "NON-RTIC-Transit-EQX-VA-Gen2-to-AZ-GOV-PRD-MAA-VA"
$virtualNetwork6Peerings.AllowForwardedTraffic = $true
$VirtualNetwork6Peerings.AllowGatewayTransit = $true
Set-AzureRmVirtualNetworkPeering -VirtualNetworkPeering $VirtualNetwork6Peerings














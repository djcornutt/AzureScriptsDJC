<# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"
#>


$notagsfound = $null
$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy hh:mm')
$smtpserver = "ice-dhs-gov.mail.protection.outlook.com"
$emailsubjectline = "Untagged Resource Group list"
$emailbody = "Attached is the untagged RG list:"



$subscriptions = get-azsubscription

foreach ($subscription in $subscriptions)
    {
        select-azsubscription -subscription $subscription.Id
  
        #grabs all RG's
        $rgnames = (Get-AzResourceGroup) # | Where-Object {($_.ResourceGroupName -match "AZ-GOV-MGMT-IC-TEST-VA")}
        foreach ($rgname in $rgnames)
        {
            #grab the RGs tags
            $rgtags = (Get-AzResourceGroup -Name $rgname.resourcegroupname).Tags
            write-host $rgname.Tags
        
            if ($rgtags.count -eq 0)
                {
                write-host "no tags found $rgname" -ForegroundColor "red"
                $notagsfound += ($rgname + ";")
                }

            else
                {
                write-host "tags found $rgname" -ForegroundColor "green"


                    $resourceid = (Get-AzResource -ResourceGroupName $rgname.ResourceGroupName).ResourceId

                    #push tags, Name fields for each device will have to be done manually, if too many, write another script!!
                      foreach ($id in $resourceid) 
                            {
                            write-host $id
                            #pushes the RG tags down to resources within as long as the RG itself is tagged
                            if ($rgtags -ne $null)
                                {
                                Update-AzTag -ResourceId $id -tag $rgtags -Operation Merge
                                }
                            }
                }
        }
    }

write-host $notagsfound

if ($notagsfound -ne $null)

    {
    write-host "Tagging anomolies detected... sending reports"

    $notagsfound | ConvertTo-json | out-File .\notagsfound$date.json
    #Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "BrieAnne.J.Julian@associates.ice.dhs.gov" -Subject $emailsubjectline -Body $emailbody $notagsfound -SmtpServer $smtpserver
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Sanjeev.S.Punn@associates.ice.dhs.gov" -Subject $emailsubjectline -Body $emailbody -SmtpServer $smtpserver -Attachments '.\notagsfound.json'
    Send-MailMessage -From "ICE_Automation_Notification@ice.dhs.gov" -To "Drew.Cornutt@associates.ice.dhs.gov" -Subject $emailsubjectline -Body $emailbody -SmtpServer $smtpserver -Attachments '.\notagsfound.json'
    }

if ($notagsfound -eq $null)
    {
        write-host "No errors found in any tags"
    }




#This was in AzFn App azgovmgmttoolsautomation7

#Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    #Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

# Excel module is required for the reports. This path is only valid in Azure Function.
import-module 'D:\home\site\wwwroot\Costs_and_Billing_Function_3\Modules\ImportExcel\ImportExcel.psd1'

function New-CellData {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Does not change system state')]
    param(
        $Range,
        $Value,
        $Format
    )
    $setFormatParams = @{
        Worksheet    = $worksheet
        Range        = $Range
        NumberFormat = $Format
    }
    if ($Value -is [string] -and $Value.StartsWith('=')) {
        $setFormatParams.Formula = $Value
    }
    else {
        $setFormatParams.Value = $Value
    }
    Set-ExcelRange @setFormatParams

}
$TagName = 'BillingPOC'

#$date = (Get-Date).AddDays(-7).ToString('yyyy-MM-dd')
#$weekbeforedate = (Get-Date).AddDays(-13).ToString('yyyy-MM-dd')

#fixed dates
#$date = "2021-10-22"
#$weekbeforedate = "2021-10-16"

$CurrentTime = [System.DateTime]::Parse((date).ToString("yyyy.MM.dd"))
$Time = [System.Timespan]::Parse("23:59")
$date = $CurrentTime.AddDays(-0).Add($Time).ToString("yyyy-MM-dd")

$CurrentTime = [System.DateTime]::Parse((date).ToString("yyyy.MM.dd"))
$Time = [System.Timespan]::Parse("00:00")
$weekbeforedate = $CurrentTime.AddDays(-6).add($time).ToString("yyyy-MM-dd")

$smtpserver = 'dc1-smtp.irmnet.ds2.dhs.gov'

#$subscriptions = Get-AzSubscription
$subscriptions = Get-AzSubscription -SubscriptionName "mgmt-ops"
foreach ($subscription in $subscriptions) {
    Select-AzSubscription -Subscription $subscription.Id

    $context = Get-AzContext
    Set-AzContext -Context $context

    #gets a list of filtered RG's with the matched Tag Name
    #$resourcegroups = Get-AzResourceGroup | Where-Object { ($_.Tags.Keys -match $TagName) }
    $resourcegroups = Get-AzResourceGroup | Where-Object { ($_.tags.keys -match $TagName) -and ($_.ResourceGroupName -eq "az-gov-mgmt-tools-va") }

    # build all the reports first
    foreach ($resourcegroup in $resourcegroups) {
        $pathandfilexlsx = Join-Path -Path '.' -ChildPath "ConsumptionUsageDetail-$($resourceGroup.ResourceGroupName)-$($date).xlsx"
        $output = Get-AzConsumptionUsageDetail -StartDate $weekbeforedate -EndDate $date -ResourceGroup $resourcegroup.ResourceGroupName -IncludeMeterDetails -IncludeAdditionalProperties
        $output | Select-Object 'InstanceName', 'InstanceLocation', 'product', 'ConsumedService', 'usagestart', 'usageend', 'usagequantity', 'pretaxcost' | Export-Excel -Path $pathandfilexlsx -WorksheetName $resourcegroup.ResourceGroupName -Numberformat 'General' -AutoSize -AutoFilter -FreezeTopRow -Calculate
    }

    # get a list of unique contacts
    $contacts = ($resourcegroups.Tags).BillingPOC 
    $contacts = ($contacts -split ',').Trim()
    $contacts = ($contacts -split ';').Trim()
    $contacts = $contacts | Select-Object -Unique

    # loop through individual contacts instead of resourcegroups
    foreach ($contact in $contacts) {
        # attach all ResourceGroups that where the individual is identified
        $attachments = [System.Collections.ArrayList]::new()
        $resourcegroups | Where-Object { $_.Tags[$TagName] -like "*$($contact)*" } | ForEach-Object {
            $resourceGroup = $_
            $attachments += Join-Path -Path '.' -ChildPath "ConsumptionUsageDetail-$($resourceGroup.ResourceGroupName)-$($date).xlsx"
        }

        $subject = ('Azure Consumption Usage Details')
        $body = -join ('Hello, This is an automated message sending a document.  Attached in this e-mail is the Azure Usage and Consumption Report for the Resource Group ' + $resourcegroup.ResourceGroupName + ' Begining from ' + $weekbeforedate + ' and ending on ' + $date + '.')
        Send-MailMessage -From Billing_ICE_Automation_Notification@noreply.com -To $contact -Subject $subject -Body $body -SmtpServer $smtpserver -Attachments $attachments
    }

    # clean up all files
    Remove-Item -Path "ConsumptionUsageDetail-*.xlsx"
}


$path = Get-location
$logfile = '\functionlogfile.txt'
$filepath = -join($($path),$($logfile))
$functiondate = (Get-Date).AddDays(0).ToString('')
$message = "Function has been executed successfully on: $functiondate"
write-host $message
$message | out-file -FilePath $filepath -Append


﻿
$ResourceGroupName = "AZ-GOV-NP-ERO-IRS-VA"

#exclude 2 VMs here, add more if required with a new -and () command
#-name used to specify one VM only


$vms = Get-AzVm -ResourceGroupName $ResourceGroupName 

$date = Get-Date -format "yyyyMMddhhmm"

foreach ($vm in $vms) {

$disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
$snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
$snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig
Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"

    $i = 0
    foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
        $i++
        $disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $dataDisk.Name
        $snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
        $snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_data_' + $i + $date) -Snapshot $snapConfig
        Write-Host "Snapshot created on DATA disk with file name labeled as: " $($vm.Name + '_DATA_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
    }
}


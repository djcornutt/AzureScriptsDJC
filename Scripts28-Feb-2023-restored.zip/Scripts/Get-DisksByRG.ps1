﻿Get-AzResource -ResourceType Microsoft.Compute/disks | where {$_ResourceGroupName -eq 'AZ-GOV-PROD-EHR-VA'}

#Get-AzDisk -ResourceGroupName AZ-GOV-PRD-MAA-SPGSS-VA  | where {$_Type -contains 'A1PPRTFS200'}

Add-AzKeyVaultKey -VaultName azgovprdmaaspgsskeyvault -Name prspgsssqldba -Destination 

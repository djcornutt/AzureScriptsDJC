<# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

import-module 'D:\home\site\wwwroot\Costs_and_Billing_Function_2\Modules\ImportExcel\ImportExcel.psd1'
#>
function New-CellData {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Does not change system state')]
    param(
        $Range,
        $Value,
        $Format
    )
    $setFormatParams = @{
        Worksheet    = $worksheet
        Range        = $Range
        NumberFormat = $Format
    }
    if ($Value -is [string] -and $Value.StartsWith('=')) {
        $setFormatParams.Formula = $Value
    }
    else {
        $setFormatParams.Value = $Value
    }
    Set-ExcelRange @setFormatParams

}
$TagName = 'BillingPOC'

$date = (Get-Date).AddDays(0).ToString('yyyy-MM-dd')
$weekbeforedate = (Get-Date).AddDays(-7).ToString('yyyy-MM-dd')
$smtpserver = 'dc1-smtp.irmnet.ds2.dhs.gov'

$subscriptions = Get-AzSubscription
foreach ($subscription in $subscriptions) {
    Select-AzSubscription -Subscription $subscription.Id

    $context = Get-AzContext
    Set-AzContext -Context $context

    #gets a list of filtered RG's with the matched Tag Name
    #$resourcegroups = Get-AzResourceGroup | Where-Object { $_.Tags.Keys -match $TagName }  RESTORE FOR PROD
    #Drew's testing RGs defined 

    $RGtest = @(

        'AZ-GOV-MGMT-IC-TEST4-VA'
        'AZ-GOV-MGMT-IC-TEST3-VA'
        'AZ-GOV-MGMT-IC-TEST2-VA'
    )

    # $resourcegroups = Get-AzResourceGroup -Name 'AZ-GOV-MGMT-IC-TEST4-VA' | Where-Object { $_.Tags.Keys -match $TagName }
    $resourcegroups = foreach ($RG in $RGtest) 
    { Get-AzResourceGroup -Name $RG | Where-Object { $_.Tags.Keys -match $TagName } }

   

    # build all the reports first
    foreach ($resourcegroup in $resourcegroups) {
        $pathandfilexlsx = Join-Path -Path '.' -ChildPath "ConsumptionUsageDetail-$($resourceGroup.ResourceGroupName)-$($date).xlsx"
        $output = Get-AzConsumptionUsageDetail -StartDate $weekbeforedate -EndDate $date -ResourceGroup $resourcegroup.ResourceGroupName -IncludeMeterDetails -IncludeAdditionalProperties
        $output | Select-Object 'InstanceName', 'InstanceLocation', 'product', 'ConsumedService', 'usagestart', 'usageend', 'usagequantity', 'pretaxcost' | Export-Excel -Path $pathandfilexlsx -WorksheetName $resourcegroup.ResourceGroupName -Numberformat 'General' -AutoSize -AutoFilter -FreezeTopRow -Calculate
    }

    # get a list of unique contacts
    $contacts = ($resourcegroups.Tags).BillingPOC 
    $contacts = ($contacts -split ',').Trim()
    $contacts = ($contacts -split ';').Trim()
    $contacts = $contacts | Select-Object -Unique

    # loop through individual contacts instead of resourcegroups
    foreach ($contact in $contacts) {
        # attach all ResourceGroups that where the individual is identified
        $attachments = [System.Collections.ArrayList]::new()
        $resourcegroups | Where-Object { $_.Tags[$TagName] -like "*$($contact)*" } | ForEach-Object {
            $resourceGroup = $_
            $attachments += Join-Path -Path '.' -ChildPath "ConsumptionUsageDetail-$($resourceGroup.ResourceGroupName)-$($date).xlsx"
        }

        $subject = ('Azure Consumption Usage Details')
        $body = -join ('Hello, This is an automated message sending a document.  Attached in this e-mail is the Azure Usage and Consumption Report for the Resource Group ' + $resourcegroup.ResourceGroupName + ' Begining from ' + $weekbeforedate + ' and ending on ' + $date + '.')
        Send-MailMessage -From Testerossa_ICE_Automation_Notification@noreply.com -To $contact -Subject $subject -Body $body -SmtpServer $smtpserver -Attachments $attachments
    }

    # clean up all files
    # should be save to remove all ConsumptionUsageDetail files
    Remove-Item -Path "ConsumptionUsageDetail-*.xlsx"
}

#############################################################
<#
$contacts = @(

    'drew.cornutt@associates.ice.dhs.gov'
    'Sanjeev.S.Punn@associates.ice.dhs.gov'
    'drew.cornutt@associates.ice.dhs.gov'
)
#>
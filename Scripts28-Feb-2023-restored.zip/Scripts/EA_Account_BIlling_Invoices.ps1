<# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"
#>

$smtpserver = 'ice-dhs-gov.mail.protection.outlook.com'

$context = select-azsubscription -subscriptionid "29370e93-f039-4eb3-b858-7b3467603fc4"
set-azcontext $context

$enrollments = @("4890265","6377074")

foreach ($enrollment in $enrollments)
{
    
    $key = (Get-AzKeyVaultSecret -VaultName "AZGOVMGMTTOOLSKVAULT1VA" -Name "ea-account-$enrollment").SecretValue | ConvertFrom-SecureString -asplaintext
    #used this below for testing if the FN can grab the key.
    #write-output $key


    $beginmonth = Get-Date -Year $((Get-Date).AddMonths(-1).Year) -month $((Get-Date).AddMonths(-1).Month) -Day 1 -Hour 0 -Minute 0 -Second 0
    $endmonth = ($beginmonth).AddMonths(1).AddSeconds(-1)

    $startdate = $beginmonth.ToString('yyyy-MM-dd')
    $enddate = $endmonth.ToString('yyyy-MM-dd')    
    


    #$uri = "https://consumption.azure.com/v3/enrollments/$enrollment/usagedetails/download?startTime=$startdate&endTime=$enddate"
    #$uri = "https://management.azure.com/$enrollment/providers/Microsoft.Consumption/usageDetails?api-version=2021-10-01"
    $uri = "https://management.azure.com/providers/Microsoft.Billing/EnrollmentAccounts/4890265/providers/Microsoft.Consumption/usageDetails?api-version=2021-10-01?startTime=$startdate&endTime=$enddate"
    $headers = @{
            'Authorization' = "Bearer $key";
        }

    $filename = ($enrollment +"-"+ $startdate +"-"+ $enddate)
    write-output $filename
    $response = Invoke-RestMethod -Uri $Uri -Method get -Headers $Headers | Out-File "$filename.txt"
    Compress-Archive -Path "$filename.txt" -DestinationPath "$filename.zip" -force
        

    $storageAccount = Get-AzStorageAccount -ResourceGroup "AZ-gov-mgmt-tools-VA" -Name "azgovmgmtbillinginvoices"
    #write-output $storageAccount
    Set-AzStorageBlobContent -File "$filename.zip" -Context $storageAccount.Context -Container invoices -force

}

# del "$filename.zip","$filename.txt"

$subject = "AZ Billing Invoice automation"
$body = "This is an automated message being sent to you to indicate that the latest billing report has been kicked off and is saved on the billing invoice storage account: azgovmgmtbillinginvoices"

# Send-MailMessage -From "Billing_ICE_Automation_Notification@ice.dhs.gov" -To "richard.p.inzunza@ice.dhs.gov" -Subject $subject -Body $body -SmtpServer $smtpserver
Send-MailMessage -From "Billing_ICE_Automation_Notification@ice.dhs.gov" -To "drew.cornutt@associates.ice.dhs.gov" -Subject $subject -Body $body -SmtpServer $smtpserver
# Send-MailMessage -From "Billing_ICE_Automation_Notification@ice.dhs.gov" -To "mihs@microsoft.com" -Subject $subject -Body $body -SmtpServer $smtpserver


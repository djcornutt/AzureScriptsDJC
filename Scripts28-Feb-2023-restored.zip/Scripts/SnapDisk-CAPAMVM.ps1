#Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

########### Script starts here! #############

Set-AzContext -SubscriptionName 'Mgmt-Ops'

#$ResourceGroupName = 'AZ-GOV-MGMT-OPS-PAM-VA'
$RG = (Get-AzResourceGroup -Name 'AZ-GOV-MGMT-OPS-PAM-VA')

$PAMVM = @(
    "A1IPRPAMPAM001",
    "A1IPRPAMPAM010"
)

foreach ($VMName in $PAMVM) {
    
$vm = Get-AzVM -name $VMName -ResourceGroupName $RG.ResourceGroupName
    
$date = Get-Date -format "yyyyMMddhhmm"
    
  
$disk = Get-AzDisk -ResourceGroupName $RG.ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
$snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
    
#the var stores the snap config that is created for date sorting and deletion evaluation
$snapshot = New-AzSnapshot -ResourceGroupName $RG.ResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig
Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"

$i = 0
foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
    $i++
    $disk = Get-AzDisk -ResourceGroupName $RG.ResourceGroupName -DiskName $dataDisk.Name
    $snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
    $snapshot = New-AzSnapshot -ResourceGroupName $RG.ResourceGroupName -SnapshotName $($vm.Name + '_data_' + $i + $date) -Snapshot $snapConfig
    Write-Host "Snapshot created on DATA disk with file name labeled as: " $($vm.Name + '_DATA_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
}

<# Insert code below for date evaluation before deleting
    For now this will just pile up daily snapshots#>

    # Code below deletes any snapshot older that 30 days but only if there are at least 30 snapshots #

    $date = (Get-Date).AddDays(-30).ToUniversalTime()

$Snaps = Get-AzSnapshot -ResourceGroupName $RG.ResourceGroupName | Where-Object {$_.Name -match $vm.Name}

    foreach ($snap in $snaps) {

        if ($snap.TimeCreated -lt $date) 

        {   
            $snaps.Count -gt 30

            Remove-AzSnapshot -ResourceGroupName $RG.ResourceGroupName -SnapshotName $snap.Name -Force;

            Write-Host "Snapshot was older than 30 days and was deleted" -ForegroundColor "Magenta"
        
        }
            

        else 
        
        {
            Write-host "This snap will not be deleted because it is less than 30 days old or there are less than 30 snaps in this RG" -ForegroundColor "Green"
        }
    }
}

            $FinalOutput = @()
            #$obj = New-Object psobject
            #$obj | Add-Member -MemberType NoteProperty -name RGName -value $rgname.ResourceGroupName
            #$obj | Add-Member -MemberType NoteProperty -name Owner -Value $rgname.Tags.ResourcePOC 

$subscriptions = get-azsubscription

foreach ($subscription in $subscriptions)
    {
        select-azsubscription -subscription $subscription.Id
  
        #grabs all RG's
        $rgnames = (Get-AzResourceGroup) #| Where-Object {($_.ResourceGroupName -match "AZ-GOV-MGMT-IC-TEST-VA")}
        foreach ($rgname in $rgnames)
        {
            #grab the RGs tags
            #$rgtags = (Get-AzResourceGroup -Name $rgname.resourcegroupname).Tags
            #write-host $rgname.Tags
        
          <#  if ($rgtags.count -eq 0)
                {
                write-host "no tags found $rgname" -ForegroundColor "red"
                $notagsfound += ($rgname + ";")
                }

            else
                {
                write-host "tags found "$rgname.ResourceGroupName"" -ForegroundColor "green"
                }
#>
                $FinalOutput += New-Object psobject -Property @{
                    RGName = $rgname.ResourceGroupName
                    Owner = $rgname.tags.ResourcePOC 
                    }
        

                
        }

        }
        $FinalOutput | Select-Object -Property RGName,Owner | Export-Csv -Path .\RGOwner.csv -NoTypeInformation

        #$FinalOutput | out-file -FilePath ./RGOwners.csv

<#             $contacts = $rgname.Tags.ResourcePOC 
            Write-Host ""$contacts""
            $RG = $rgname.ResourceGroupName
             RG-ByOwner.csv -InputObject $RG, $contacts -append
         
            $rgname | Select-Object -property ResourceGroupName |
            Export-Csv -Path .\RGOwner.csv -NoTypeInformation -Append
            $rgname.Tags | Select-Object -property ResourcePOC |
            Export-Csv -Path .\RGOwner.csv -NoTypeInformation -Append

            $obj = New-Object psobject
            $obj | Add-Member -MemberType NoteProperty -name RGName -value $rgname.ResourceGroupName
            $obj | Add-Member -MemberType NoteProperty -name Owner -Value $rgtags.ResourcePOC#>
            
            
            #Get-AzResourceGroup | Where-Object {($_.ResourceGroupName -match "AZ-GOV-MGMT-IC-TEST-VA")} | Select-Object -Property ResourceGroupName,ResourcePOC | Write-Host
            
            
            
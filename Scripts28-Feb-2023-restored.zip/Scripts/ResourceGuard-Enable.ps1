<# This script sets the RSV to use Resource Guard. Do not run the entire script as it is broken up in sections by Sub/Location/RG.
   It was done this way along with discovery of where RSVs all were. This script can be consolidated to run by sub and just iterate
   all RGs but since all have been enabled as of 22-Dec-2022 you will get a lot of console chatter to parse to see what new ones it enabled.
   Remeber that Resource Guard does not care about the sub of the RSV it is protecting but is dependant on Location and will fail if they don't match.

   -Drew Cornutt Microsoft
#>

#Resource Group the RSV is in
$rg = 'AZ-GOV-MGMT-TOOLS-DR-AZ'

#Resource Group in RG Tenant containing the Resource Guard
$ResourceGuardRG = 'AZ-GOV-POC-RG-AZ'

#Resource Guard Name
$ResourceGuardName = 'ResourceGuardVA'

$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName $rg).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) {
    #
    Set-AzRecoveryServicesResourceGuardMapping `
        -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$rg/providers/Microsoft.RecoveryServices/vaults/$RSV" `
        -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/$ResourceGuardRG/providers/Microsoft.DataProtection/resourceGuards/$ResourceGuardName" `
        -Token $token
}

#############################
  
$rg = 'AZ-GOV-MGMT-TOOLS-AZ'
$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName $rg).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) {
    #
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$rg/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-AZ/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardAZ" -Token $token
}

#Do an interation for Prod-Ops, AZ-GOV-PRD-MAA-DR-AZ

$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName 'AZ-GOV-PRD-MAA-DR-AZ').Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/AZ-GOV-PRD-MAA-DR-AZ/providers/Microsoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-AZ/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardAZ" -Token $token
}


#Do one for ERO Prod-Ops

$RG = 'AZ-GOV-PRD-ERO-DR-AZ'
$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-AZ/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardAZ" -Token $token
}

#NP-ERO-AZ

Set-AzContext -SubscriptionName NonProd-ERO
$RG = 'AZ-GOV-NP-ERO-AZ'
$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-AZ/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardAZ" -Token $token
}


#NP-HSI-AZ

Set-AzContext -SubscriptionName NonProd-HSI
$RG = 'AZ-GOV-NP-HSI-AZ'
$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-AZ/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardAZ" -Token $token
}

#NP-MAA-AZ

Set-AzContext -SubscriptionName NonProd-MandA
$RG = 'AZ-GOV-NP-MAA-AZ'
$AZRSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $AZRSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-AZ/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardAZ" -Token $token
}


#####################
# NO FPS Prod-Ops!!!!
#####################


# MGMT-VA 

set-azcontext -subscriptionName mgmt-ops

$RG = 'AZ-gov-mgmt-tools-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}

# Prod-Ops VA 


$RG = 'AZ-GOV-PRD-MAA-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}


#ERO-VA
AZ-GOV-PRD-ERO-VA

set-azcontext -subscriptionName prod-ops

$RG = 'AZ-GOV-PRD-ERO-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}

#HSI-VA

set-azcontext -subscriptionName prod-ops

$RG = 'AZ-GOV-PRD-HSI-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}

#TIC-VA



set-azcontext -subscriptionName prod-ops

$RG = 'AZ-GOV-PRD-TIC-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}

#NonProdMandA - VA


set-azcontext -subscriptionName NonProd-MandA

$RG = 'AZ-GOV-NP-MAA-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}

#NP-HSI-VA


set-azcontext -subscriptionName NonProd-HSI

$RG = 'AZ-GOV-NP-HSI-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}

#NP-ERO-VA

set-azcontext -subscriptionName NonProd-ERO


$RG = 'AZ-GOV-NP-ERO-VA'
$VARSVs = (get-azrecoveryServicesVault -resourceGroupName $RG).Name


$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token

foreach ($RSV in $VARSVs) { 
    Set-AzRecoveryServicesResourceGuardMapping -VaultId "/subscriptions/29370e93-f039-4eb3-b858-7b3467603fc4/resourceGroups/$RG/providers/Mic 
rosoft.RecoveryServices/vaults/$RSV" -ResourceGuardId "/subscriptions/2666c4f7-ea83-42a7-afa1-1f56189a8ac2/resourcegroups/AZ-GOV-POC-RG-VA/providers/Microsoft.DataProtection/resourceGuards/ResourceGuardVA" -Token $token
}
##################################

$token = (Get-AzAccessToken -TenantId "7e5ead3a-4871-41eb-b86e-44f3711120c6").Token


$VaultID = Get-AzRecoveryServicesVault -Name "AZ-GOV-MGMT-TOOLS-VAULT-VA-1"

Set-AzRecoveryServicesVaultProperty -VaultId $VaultID.ID -SoftDeleteFeatureState Disable


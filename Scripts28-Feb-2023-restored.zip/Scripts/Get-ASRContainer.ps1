


$Vname = 'AZ-GOV-PRD-MAA-VAULT-DR-AZ-4'
$vault = Get-AzRecoveryServicesVault -name $vname
Set-AzRecoveryServicesVaultContext -Vault $vault
$fabric = Get-AzRecoveryServicesAsrFabric -FriendlyName 'USGOV Virginia'
$container = Get-AzRecoveryServicesAsrProtectionContainer -Fabric $fabric
$ProtectedVMs = Get-AzRecoveryServicesAsrReplicationProtectedItem -ProtectionContainer $container

Write-Output -InputObject $ProtectedVMs.FriendlyName
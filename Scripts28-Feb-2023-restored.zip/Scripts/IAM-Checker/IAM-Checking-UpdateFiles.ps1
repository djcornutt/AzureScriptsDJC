<# Run this to update reference files for the IAM Checking script running in Automation4
Then upload the files via KUDU console using drag/drop from local files system
At some future time update this script with Functino App file path names then run it in
a separate function but leave it manual so no CRON timer config#>


$date = (Get-Date).AddDays(0).ToString('MM-dd-yyyy-hhmm')


get-azroleDefinition -name "Devtest Labs User" | ConvertTo-Json | out-file "Devtest_Labs_User_$date.json"
get-azroleDefinition -name "Key Vault Contributor" | ConvertTo-Json | out-file "Key_Vault_Contributor_$date.json"
get-azroleDefinition -name "Monitoring Contributor" | ConvertTo-Json | out-file "Monitoring_Contributor_$date.json"
get-azroleDefinition -name "Network Contributor" | ConvertTo-Json | out-file "Network_Contributor_$date.json"      
get-azroleDefinition -name "Private dns zone contributor" | ConvertTo-Json | out-file "Private_dns_zone_contributor_$date.json"
get-azroleDefinition -name "Site recovery contributor" | ConvertTo-Json | out-file "Site recovery contributor_$date.json"      
get-azroleDefinition -name "Site recovery operator" | ConvertTo-Json | out-file "Site_recovery_operator_$date.json"      
get-azroleDefinition -name "Sql db contributor" | ConvertTo-Json | out-file "Sql_db__contributor_$date.json"
get-azroleDefinition -name "Storage account contributor" | ConvertTo-Json | out-file "Storage_account_contributor_$date.json"
get-azroleDefinition -name "Storage blob data contributor" | ConvertTo-Json | out-file "Storage_blob_data_contributor_$date.json"
get-azroleDefinition -name "Tag Contributor" | ConvertTo-Json | out-file "Tag_contributor_$date.json"
get-azroleDefinition -name "Data Factory Contributor" | ConvertTo-Json | out-file "Data_Factory_Contributor_$date.json"
get-azroleDefinition -name "AzureML Data Scientist" | ConvertTo-Json | out-file "AzureML_Data_Scientist_$date.json"
Get-AzRoleDefinition -name "Azure Maps Contributor" | ConvertTo-Json | out-file "Azure_Maps_Contributor_$date.json"
Get-AzRoleDefinition -name "Desktop Virtualization Contributor" | ConvertTo-Json | out-file "Desktop_Virtualization_Contributor_$date.json"


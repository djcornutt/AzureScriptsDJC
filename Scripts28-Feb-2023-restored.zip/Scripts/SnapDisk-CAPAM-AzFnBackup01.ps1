# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

########### Script starts here! #############

Set-AzContext -SubscriptionName 'Mgmt-Ops'

$ResourceGroupName = "AZ-GOV-MGMT-OPS-PAM-VA"
    
$vm = get-azvm -name "A1IPRPAMPAM001" -ResourceGroupName $ResourceGroupName
    
$date = Get-Date -format "yyyyMMddhhmm"
    
  
$disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
$snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
    
#this var stores the snap config that is created for date sorting and deletion evaluation
$snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig

Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"


# Code below deletes any snapshot older that 30 days but only if there are at least 30 snapshots #

    $date = (Get-Date -AsUTC).AddDays(-30)

$Snaps = Get-AzSnapshot -ResourceGroupName $ResourceGroupName | Where-Object {$_.Name -match $vm.Name}

    foreach ($snap in $snaps) {

        if ($snap.TimeCreated -lt $date) 

        {   
            $snaps.Count -gt 30

            Remove-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $snap.Name -Force;

            Write-Host "Snapshot was older than 30 days and was deleted" -ForegroundColor "Magenta"
        
        }
            

        else 
        
        {
            Write-host "This snap will not be deleted because it is less than 30 days old or there are less than 30 snaps in this RG" -ForegroundColor "Green"
        }
    }


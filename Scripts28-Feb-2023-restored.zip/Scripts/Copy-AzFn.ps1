
# grab a source webapp to copy
$sourceapp = Get-AzWebApp -ResourceGroupName AZ-GOV-MGMT-TOOLS-VA -Name azgovmgmttoolsautomation1

# Create the new one, insert new name or use $sourceapp.Name if moving to another RG/Sub
New-AzWebapp -ResourceGroupName AZ-GOV-MGMT-TOOLS-VA -Name  -Location $sourceapp.Location -AppServicePlan azgovmgmticops1 -SourceWebApp $sourceapp -AseResourceGroupName AZ-GOV-NP-FUNCTIONS-VA -AseName AZ-GOV-NP-FUNCTIONS-01-VA



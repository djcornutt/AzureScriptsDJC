﻿#Provide the subscription Id of the subscription where snapshot is created
$subscriptionId = "73df759a-598a-451c-86f5-c12d90d9c5d4"
$ResourceGroupName = "AZ-GOV-TRAINING-VA"

#Provide Shared Access Signature (SAS) expiry duration in seconds e.g. 3600.
#Know more about SAS here: https://docs.microsoft.com/en-us/azure/storage/storage-dotnet-shared-access-signature-part-1
$sasExpiryDuration = "3600"

#Provide storage account name where you want to copy the snapshot. 
$storageAccountName = "azgovtrainingvadiag244"

#Name of the storage container where the downloaded snapshot will be stored
$storageContainerName = "export"

#Provide the key of the storage account where you want to copy snapshot. 
$storageAccountKey = 'VlHBYJGNAg0b07Zwa2BNgExIZNIxMnaoPtQi21KDfX/UTveYs8AQkESOrTNfnkpvBi1Hxs5Q9mk8H+w7lA6w0w=='




#exclude 2 VMs here, add more if required with a new -and () command
$vms = Get-AzVm -ResourceGroupName $ResourceGroupName | Where-Object {($_.name -bor "testvm1") , ($_.name -bor "testvm4") }

$date = Get-Date -format "yyyyMMddhhmm"

foreach ($vm in $vms) {

$disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
$snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
$snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig
Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
$destinationOSVHDFileName = $snapshot.name
$snapshotname = $snapshot.Name
$sas = Grant-AzureRmSnapshotAccess -ResourceGroupName $ResourceGroupName -SnapshotName $SnapshotName  -DurationInSecond $sasExpiryDuration -Access Read 
$destinationContext = New-AzureStorageContext –StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey  
Start-AzureStorageBlobCopy -AbsoluteUri $sas.AccessSAS -DestContainer $storageContainerName -DestContext $destinationContext -DestBlob $destinationOSVHDFileName

    $i = 0
    foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
        $i++
        $disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $dataDisk.Name
        $snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
        $snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_data_' + $i + $date) -Snapshot $snapConfig
        Write-Host "Snapshot created on DATA disk with file name labeled as: " $($vm.Name + '_DATA_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
        $destinationVHDFileName = $snapshot.name
        $snapshotname = $snapshot.Name
        $sas = Grant-AzureRmSnapshotAccess -ResourceGroupName $ResourceGroupName -SnapshotName $SnapshotName  -DurationInSecond $sasExpiryDuration -Access Read 
        $destinationContext = New-AzureStorageContext –StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey  
        Start-AzureStorageBlobCopy -AbsoluteUri $sas.AccessSAS -DestContainer $storageContainerName -DestContext $destinationContext -DestBlob $destinationVHDFileName
        #Get-AzureStorageBlobCopyState -WatiForComplete


   }
}


$diskconfig = New-AzDiskConfig -Location 'usgovvirginia' -DiskSizeGB 80 -AccountType Standard_LRS -OsType Windows -CreateOption Empty -EncryptionSettingsEnabled $true;
$secretUrl = https://myvault.vault-int.azure-int.net/secrets/123/;
$secretId = '/subscriptions/0000000-0000-0000-0000-000000000000/resourceGroups/ResourceGroup01/providers/Microsoft.KeyVault/vaults/TestVault123';
$keyUrl = https://myvault.vault-int.azure-int.net/keys/456;
$keyId = '/subscriptions/0000000-0000-0000-0000-000000000000/resourceGroups/ResourceGroup01/providers/Microsoft.KeyVault/vaults/TestVault456';
$diskconfig = Set-AzDiskDiskEncryptionKey -Disk $diskconfig -SecretUrl $secretUrl -SourceVaultId $secretId;
$diskconfig = Set-AzDiskKeyEncryptionKey -Disk $diskconfig -KeyUrl $keyUrl -SourceVaultId $keyId;
New-AzDisk -ResourceGroupName 'ResourceGroup01' -DiskName 'Disk01' -Disk $diskconfig;






#Prepare the VM parameters
$DestSubscriptionID = "9ef1a393-95a9-4d0b-acc1-f51b67a68e90"
$DestrgName = "AZ-GOV-TRAINING2-VA"
$Destlocation = "usgovvirginia"
$Destvnet = "AZ-GOV-NP-MAA-VA"
$Destsubnet = "/subscriptions/$DestSubscriptionID/resourceGroups/DestrgName/providers/Microsoft.Network/virtualNetworks/$Destvnet/subnets/gov-np-maa-web-1a"
$DestvmName = "VM01"
$DestnicName = ($DestvmName + "Nic-01")

$DestosDiskName = "VM01-OSDisk"
$DestosDiskUri = "https://$storageAccountName.blob.core.windows.net/$storageContainerName/$destinationOSVHDFileName"
$DestVMSize = "Standard_DS4_v2"
$DeststorageAccountType = "StandardLRS"
#$DestIPaddress = "10.10.10.10"
#Create the VM resources
$DestIPconfig = New-AzureRmNetworkInterfaceIpConfig -Name "IPConfig1" -PrivateIpAddressVersion IPv4 -PrivateIpAddress $IPaddress -SubnetId $subnet
$Destnic = New-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $rgName -Location $location -IpConfiguration $IPconfig
$DestvmConfig = New-AzureRmVMConfig -VMName $vmName -VMSize $VMSize
$Destvm = Add-AzureRmVMNetworkInterface -VM $vmConfig -Id $nic.Id
$DestosDisk = New-AzureRmDisk -DiskName $osDiskName -Disk (New-AzureRmDiskConfig -AccountType $storageAccountType -Location $location -CreateOption Import -SourceUri $osDiskUri) -ResourceGroupName $rgName
$Destvm = Set-AzureRmVMOSDisk -VM $vm -ManagedDiskId $osDisk.Id -StorageAccountType $storageAccountType -DiskSizeInGB 128 -CreateOption Attach -Windows
$Destvm = Set-AzureRmVMBootDiagnostics -VM $vm -disable
#Create the new VM
New-AzureRmVM -ResourceGroupName $rgName -Location $location -VM $vm

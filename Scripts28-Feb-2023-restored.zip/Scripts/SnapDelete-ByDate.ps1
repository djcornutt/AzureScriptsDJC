

Set-AzContext -SubscriptionName 'Mgmt-Ops'

$ResourceGroupName = 'AZ-GOV-MGMT-IC-TEST3-VA'

$vm = get-azvm -name "DrewTestDeleteme" -ResourceGroupName $ResourceGroupName
    
$date = Get-Date -format "yyyyMMddhhmm"
    
  
$disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
$snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
    
#the var stores the snap config that is created for date sorting and deletion evaluation
$snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig
Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"

# $date = Get-Date -format "yyyyMMddhhmm"

# use this line for snaps older than 8 days
# $date = (Get-Date).AddDays(-8)

$date = (Get-Date -AsUTC).AddMinutes(-5)

$Snaps = Get-AzSnapshot -ResourceGroupName 'AZ-GOV-MGMT-IC-TEST3-VA' | Where-Object {$_.Name -match $vm.Name}

    foreach ($snap in $snaps) {

        if ($snap.TimeCreated -lt $date)

        {   
            
            Remove-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $snap.Name -Force;

            Write-Host "Snapshot was older than 30 days and was deleted" -ForegroundColor "Magenta"
        
        }
            

        else 
        
        {
            Write-host "This snap will not be deleted because it is less than 30 days old or there are less than 30 snaps in this RG" -ForegroundColor "Green"
        }
    }










<#
    
    #$vms = Get-AzVm -ResourceGroupName $ResourceGroupName 
    $vms = get-azvm -name "A1IPRPAMPAM001" -ResourceGroupName $ResourceGroupName
    
    $date = Get-Date -format "yyyyMMddhhmm"
    
    foreach ($vm in $vms) {
    
    $disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
    $snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
    
    #the var stores the snap config that is created for date and deletion evaluation
    $snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig
    Write-Host "Snapshot created on OS disk with file name labeled as: " $($vm.Name + '_OS_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
    
       $i = 0
        foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
            $i++
            $disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $dataDisk.Name
            $snapConfig = New-AzSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $vm.Location
            $snapshot = New-AzSnapshot -ResourceGroupName $ResourceGroupName -SnapshotName $($vm.Name + '_data_' + $i + $date) -Snapshot $snapConfig
            Write-Host "Snapshot created on DATA disk with file name labeled as: " $($vm.Name + '_DATA_' + $date) -Snapshot $snapConfig -ForegroundColor "Green"
        }

    }

    #>

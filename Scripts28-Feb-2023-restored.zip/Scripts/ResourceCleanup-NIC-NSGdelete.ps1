####START OF SCRIPT######

<# This script searches all subs and RGs to identify unattached NICs 
and deletes them. Their are no owners and no creation dates on NICS

   Drew Cornutt - Microsoft
#>

# Only run in these 2 subs
$subscriptions = @(
    "Prod-Ops",
    "Mgmt-Ops"
)

foreach ($subscription in $subscriptions) {
    select-azsubscription -SubscriptionName $subscription

    #grabs all RG's --- *****comment out test RG when going PROD!!!!!*******
    $rgnames = (Get-AzResourceGroup)  | Where-Object { ($_.ResourceGroupName -match 'AZ-GOV-MGMT-IC-TEST2-VA') }
    #$rgnames = (Get-AzResourceGroup)  | Where-Object { ($_.ResourceGroupName -like '*-VA')}
  

    Foreach ($RG in $rgnames) {

        $networkinterface = Get-AzNetworkInterface -ResourceGroupName $rgnames.resourcegroupname
       
        Foreach ($nic in $networkinterface) {

            #$nic = (Get-AzNetworkInterface -name 'drewwilldeletevm0829').VirtualMachine
            If (!$nic.VirtualMachine) 
            {
                Write-Host "$($nic.Name) found in $($RG.ResourceGroupName) is not attached and will be deleted"
                Remove-AzNetworkInterface -Name $nic.name -ResourceGroupName $rg.ResourceGroupName -Force -ErrorAction Continue 
            }
        }
    }
}